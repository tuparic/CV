#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <poll.h>
#include <ncurses.h>
#include <signal.h>

#define MAX_QUEUE 5
#define MEM_INC_SIZE 8
#define BUF_SIZE 256
#define STAND_PORT 2030


/* Константы размеров окон */
#define WIN_HIGH 23
#define WIN_STAT_LEN 62
#define WIN_TEAMS_LEN 18
#define WIN_HELP_HIGH 5

#define GAME_SIZE 23
#define MIN(X, Y) ((X) > (Y)? (Y) : (X))
/* Строки для окна help */

#define TOO_MANY_MEMB "Too many members in this team"
#define NICK_EXISTS "Nickname already exists"
#define TEAM_EXISTS "Team already exists"
#define TEAM_DEL "Team deleted"
#define TOO_MANY_SYMB "Too many symbols"
#define CANNOT_USE "You cannot use spaces, tabs \'*\' and newlines"
#define ARR_USE "Use arrows for navigation, ESC for back"
#define GAME_USE "Ins for mine, Del for taking kit, Enter for using weapon"
#define W_F "Wrong format"
#define UNDEF_ERR "Undefined error"
#define GAME_STARTED "Game started"
#define GAME_FINISHED "Game finished"
#define LOST_CONNECT "Server connection lost"

/* Константы цветов */
#define STAND_C 1
#define INV_C 2
#define BACK_C 3
#define CH_C 4
#define CURS_C 5
#define ATTEN_C 6

/* Константы клавиш  */
#define ESC 27
#define CTRL_C 3
#define CTRL_D 4

struct Player_info{
	int tof;
	int x, y, health;
	char player_name[61], team_name[61];
	char ** map;
	int bombs;
	int bomb_t, weapon_t, start_t;
};
struct Team_info{
	int tof;
	int if_start;
	int players_num;
	int players_max;
	char team_name[61];
	struct Player_info * players;
};
struct Game_journal{
	char ** teams;
	int teams_num;
};
struct Team_info ti;
struct Player_info pi;
struct Game_journal gj;

int main_socket;
enum {Start_scr, Status_scr, Team_scr, Team_create, Team_join, Waiting_game, Waiting_team, Game_status, Members, Winner, You_win, You_lose, Game, Stop} V;
char buf[BUF_SIZE];
ssize_t n_read;
int curs_st = 0, curs_teams = 0, teams_page = 0, players_page = 0;
WINDOW * win_status, * win_teams, * win_help;
int sig = 0;
struct pollfd * fds; 

/* Освобождение памяти выделенной под карту */
void free_map(){
	int i, j;
	for(i = 0; i < pi.y; i++){
		free(pi.map[i]);
	}
	free(pi.map);
	pi.x = pi.y = 0;
	pi.map = NULL;
}

/* Освобождение памяти выделенной под список команд */
void free_teams(void){
	int i;
	for(i = 0; i < gj.teams_num; i++)
		free(gj.teams[i]);
	free(gj.teams);
	gj.teams_num = 0;
	gj.teams = NULL;
}

/* Освобождение памяти выделенной под список игроков */
void free_players(void){
	int i;
	free(ti.players);
	ti.players_num = 0;
	ti.players = NULL;
}

void sigint_wait(){
	sig = 1;
}

void end_prog();

/* Отправить сообщение об удалении команды/игрока */
void send_del(){
	int j;
	signal(SIGINT, sigint_wait);
	ti.if_start = 0;
	if(ti.tof){
		j = 3;
		write(main_socket, &j, sizeof(int));
		j = strlen(ti.team_name) + 1;
		write(main_socket, &j, sizeof(int));
		write(main_socket, ti.team_name, j);
		ti.tof = 0;
	}
	else if(pi.tof){
		j = 4;
		write(main_socket, &j, sizeof(int));
		j = strlen(pi.team_name) + 1;
		write(main_socket, &j, sizeof(int));
		write(main_socket, pi.team_name, j);
		j = strlen(pi.player_name) + 1;
		write(main_socket, &j, sizeof(int));
		write(main_socket, pi.player_name, j);
		pi.tof = 0;
	}
	else{
		j = -1;
		write(main_socket, &j, sizeof(int));
	}
	signal(SIGINT, end_prog);
	if(sig){
		end_prog();
	}

}

/* Завершить программу */
void end_prog(){
	send_del();
	close(main_socket);
	delwin(win_status);
	delwin(win_teams);
	delwin(win_help);
	endwin();
	/* Освобождение памяти */
	free(fds);
	free_map();
	free_players();
	free_teams();
	exit(0);
}

/* Написать текст str посередине строки y окна win */
void prt_center_win(WINDOW * win, char * str, int y){
	int i, tek;
	tek = getmaxx(win) - strlen(str) - 2;
	if(tek > 0){
		mvwprintw(win, y, (tek + 2) / 2,"%s", str);
	}
	else{
		wmove(win, y, 1);
		for(i = 0; i < getmaxx(win) - 2; i++)
			waddch(win, str[i]);
	}	
}

/* Обновить окно помощи */
void help_upd(char * str, int y, int color){
	wclear(win_help);
	wbkgd(win_help, COLOR_PAIR(STAND_C));
	wattron(win_help, COLOR_PAIR(INV_C));
	box(win_help, 0, 0);
	wattron(win_help, COLOR_PAIR(color));
	prt_center_win(win_help, str, y);
	wrefresh(win_help);
}

/* Завершение программы при закрытом сокете */
void channel_closed(){
	help_upd(LOST_CONNECT, 2, ATTEN_C);
	sleep(5);

	close(main_socket);
	delwin(win_status);
	delwin(win_teams);
	delwin(win_help);
	endwin();
	/* Освобождение памяти */
	free(fds);
	free_map();
	free_players();
	free_teams();
	exit(0);
}

/* Очистить сокет */
void clear_socket(){
	while((poll(&fds[0], 1, 5) > 0) && fds[0].revents && read(fds[0].fd, buf, BUF_SIZE) > 0);
}

/* Чтение списка команд */
void read_teams(void){
	int i, j, z, tek;
	if(gj.teams_num){
		strcpy(buf, gj.teams[curs_teams + teams_page * (WIN_HIGH - 3)]);		
	}
	free_teams();
	/* Число команд */
	if(read(main_socket, &gj.teams_num, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
		return;
	}
	/*printf("Teams_num = %d\n", gj.teams_num);*/
	if(gj.teams_num){
		if((gj.teams = calloc(gj.teams_num, sizeof(char *))) == NULL){
			fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			end_prog();
		}
		/* Чтение данных об очередной команде */
		for(i=0; i < gj.teams_num; i++){
			if((gj.teams[i] = calloc(61, sizeof(char))) == NULL){
				fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
					__FILE__, __LINE__ - 2,  strerror(errno));  
				end_prog();
			}
			/* Длина строки */
			if((n_read = read(main_socket, &tek, sizeof(int))) != sizeof(int)){
				fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
					__FILE__, __LINE__ - 2,  strerror(errno));
				close(main_socket);
				V = Stop;
				return;
			}
			/*printf("tek = %d\n", gj.teams_num);*/
			/* Считывание строки */
			if((n_read = read(main_socket, gj.teams[i], tek)) != tek){
				fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
					__FILE__, __LINE__ - 2,  strerror(errno));
				close(main_socket);
				V = Stop;
				return;
			}
		}
		tek = 0;
		for(i = 0; i < gj.teams_num; i++){
			if(strcmp(buf, gj.teams[i]) == 0){
				curs_teams = i % (WIN_HIGH - 3);
				teams_page = i / (WIN_HIGH - 3);
				tek = 1;
				break;
			}
		}
		if(tek){
			curs_teams = 0;
			teams_page = 0;
		}
	}
	else{
		gj.teams = NULL;
		curs_teams = 0;
		teams_page = 0;
	}
	
}

/* Чтение списка игроков */
void read_players(void){
	int i, j, z, tek;
	free_players();
	/* Число команд */
	if(read(main_socket, &ti.players_num, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
		return;
	}
	if((ti.players = calloc(ti.players_num, sizeof(struct Player_info))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		end_prog();
	}
	/* Чтение данных об очередном игроке */
	for(i=0; i < ti.players_num; i++){
		/* Длина строки */
		if((n_read = read(main_socket, &tek, sizeof(int))) != sizeof(int)){
			fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));
			close(main_socket);
			V = Stop;
			return;
		}
		/* Считывание строки */
		if((n_read = read(main_socket, ti.players[i].player_name, tek)) != tek){
			fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));
			close(main_socket);
			V = Stop;
			return;
		}
		if((n_read = read(main_socket, &ti.players[i].x, sizeof(int))) != sizeof(int)){
			fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));
			close(main_socket);
			V = Stop;
			return;
		}
		if((n_read = read(main_socket, &ti.players[i].y, sizeof(int))) != sizeof(int)){
			fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));
			close(main_socket);
			V = Stop;
			return;
		}
		if((n_read = read(main_socket, &ti.players[i].health, sizeof(int))) != sizeof(int)){
			fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));
			close(main_socket);
			V = Stop;
			return;
		}
	}
}

/* Обновить список команд на экране */
void upd_teams(void){
	int i, j;
	wclear(win_teams);
	wbkgd(win_teams, COLOR_PAIR(BACK_C));
	wattron(win_teams, COLOR_PAIR(INV_C));
	box(win_teams, 0, 0);
	wattron(win_teams, COLOR_PAIR(BACK_C));
	prt_center_win(win_teams, "    Team names   ", 1);

	wattron(win_teams, COLOR_PAIR(INV_C));
	for(i = 0; i < MIN(WIN_HIGH - 3, gj.teams_num - teams_page * (WIN_HIGH - 3)); i++){
		wmove(win_teams, 2 + i, 1);
		waddch(win_teams, ' ');
	}
	
	wattron(win_teams, COLOR_PAIR(CH_C));

	for(i = 0; i < MIN(gj.teams_num - teams_page * (WIN_HIGH - 3), WIN_HIGH - 3); i++){
		wmove(win_teams, i + 2, 2);
		for(j = 0; j < MIN(strlen(gj.teams[i + teams_page * (WIN_HIGH - 3)]), WIN_TEAMS_LEN - 3); j++)
			waddch(win_teams, gj.teams[i + teams_page * (WIN_HIGH - 3)][j]);
	}
	wrefresh(win_teams);
}

/* Обновить список игроков на экране */
void upd_players(){
	int i, j;
	wclear(win_status);
	wbkgd(win_status, COLOR_PAIR(BACK_C));
	wattron(win_status, COLOR_PAIR(INV_C));
	box(win_status, 0, 0);
	wattron(win_status, COLOR_PAIR(BACK_C));
	prt_center_win(win_status, "Team:", 6);
	prt_center_win(win_status, ti.team_name, 7);

	wattron(win_status, COLOR_PAIR(CH_C));
	prt_center_win(win_status, "     Back    ", 17);
	prt_center_win(win_status, "     Exit    ", 18);

	wattron(win_status, COLOR_PAIR(INV_C));
	for(i = 0; i < MIN(WIN_HIGH - 12, ti.players_num - players_page * (WIN_HIGH - 13) + 1); i++){
		wmove(win_status,  8 + i, 5);
		waddch(win_status, ' ');
		wmove(win_status,  8 + i, WIN_STAT_LEN - 7);
		waddch(win_status, ' ');
		wmove(win_status,  8 + i, WIN_STAT_LEN - 11);
		waddch(win_status, ' ');
		wmove(win_status,  8 + i, WIN_STAT_LEN - 15);
		waddch(win_status, ' ');
		wmove(win_status,  8 + i, WIN_STAT_LEN - 19);
		waddch(win_status, ' ');
	}
	wattron(win_status, COLOR_PAIR(STAND_C));
	mvwprintw(win_status, 8, 6, "%*.*s", WIN_STAT_LEN - 25, WIN_STAT_LEN - 25, "Nickname");
	mvwprintw(win_status, 8, WIN_STAT_LEN - 18, "%3.3s", "x");
	mvwprintw(win_status, 8, WIN_STAT_LEN - 14, "%3.3s", "y");
	mvwprintw(win_status, 8, WIN_STAT_LEN - 10, "%3.3s", "h");

	wattron(win_status, COLOR_PAIR(CH_C));

	for(i = 0; i < MIN(WIN_HIGH - 13, ti.players_num - players_page * (WIN_HIGH - 13)); i++){
		mvwprintw(win_status, 9 + i, 6, "%*.*s", WIN_STAT_LEN - 25, WIN_STAT_LEN - 25, ti.players[i + players_page * (WIN_HIGH - 13)].player_name);
		if(ti.if_start == 0){
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 18, "%3.3s", "-");
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 14, "%3.3s", "-");
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 10, "%3.3s", "-");
		}
		else{
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 18, "%3d", ti.players[i + players_page * (WIN_HIGH - 13)].x);
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 14, "%3d", ti.players[i + players_page * (WIN_HIGH - 13)].y);
			mvwprintw(win_status, 9 + i, WIN_STAT_LEN - 10, "%3d", ti.players[i + players_page * (WIN_HIGH - 13)].health);
		}
	}
	wrefresh(win_status);
}

/* Основные команды от сервера */
void syncro(int *tof){
	int i;
	if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	
	switch(i){
		case 1:
			/* Server stop */
			*tof = 0;
			channel_closed();
		break;
		case 2:
			/* Teams update */
			read_teams();
			upd_teams();
		break;
		default:
			help_upd(UNDEF_ERR, 2, ATTEN_C);
			*tof = 0;
			sleep(3);	
			V = Stop;
		break;
	}
}

/* Считывание информации об игре */
void read_game(){
	int i, j;
	free_map();	
	if(read(main_socket, &pi.x, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if(read(main_socket, &pi.y, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if((pi.map = calloc(pi.y, sizeof(char *))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		end_prog();
	}
	for(i = 0; i < pi.y; i++){
		if((pi.map[i] = calloc(pi.x, sizeof(char))) == NULL){
			fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			end_prog();
		}
		for(j = 0; j < pi.x; j++)
			if(read(main_socket, &pi.map[i][j], sizeof(char)) != sizeof(char)){
				fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
					__FILE__, __LINE__ - 2,  strerror(errno));
				close(main_socket);
				V = Stop;
			}
	}
	if(read(main_socket, &pi.health, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if(read(main_socket, &pi.bombs, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if(read(main_socket, &pi.bomb_t, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if(read(main_socket, &pi.weapon_t, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
	if(read(main_socket, &pi.start_t, sizeof(int)) != sizeof(int)){
		fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));
		close(main_socket);
		V = Stop;
	}
}

/* Обновление игры на экране */
void upd_game(){
	int i, j;
	char symb;
	wclear(win_status);
	wbkgd(win_status, COLOR_PAIR(STAND_C));
	wattron(win_status, COLOR_PAIR(INV_C));
	box(win_status, 0, 0);
	mvwvline(win_status, 1, WIN_HIGH - 1, '|', WIN_HIGH - 2);
	wattron(win_status, COLOR_PAIR(STAND_C) | A_BOLD);
	mvwprintw(win_status, 2,  WIN_HIGH + 2, "Health level: %d / 999", pi.health);
	mvwprintw(win_status, 3,  WIN_HIGH + 2, "Bombs: %d", pi.bombs);
	if(pi.start_t || pi.weapon_t)
		mvwprintw(win_status, 4,  WIN_HIGH + 2, "CANNOT USE WEAPON: %d", pi.start_t > pi.weapon_t? pi.start_t:pi.weapon_t);
	if(pi.bomb_t)
		mvwprintw(win_status, 5,  WIN_HIGH + 2, "MINING: %d", pi.bomb_t);
	
	for(i = 0; i < pi.y; i++){
		wmove(win_status, 1 + i, 1);
		for(j = 0; j < pi.x; j++){
			symb = ' '; 
			switch(pi.map[i][j]){
				case 0:
					wattron(win_status, COLOR_PAIR(STAND_C));
				break;
				case 1:
					wattron(win_status, COLOR_PAIR(INV_C));
					symb = '#';
				break;
				case 2:
					wattron(win_status, COLOR_PAIR(ATTEN_C));
					symb = 'O';
				break;
				case 3:
					wattron(win_status, COLOR_PAIR(CURS_C));
					symb = 'O';
				break;
				case 4:
					wattron(win_status, COLOR_PAIR(STAND_C));
					symb = '+';
				break;
			}
			waddch(win_status, symb);
		}
	}
	wattron(win_status, COLOR_PAIR(STAND_C));
	wrefresh(win_status);
}

int main(int argc, char * argv[]){
	int server, events, i, j, z, tek;
	struct sockaddr_in adr;
	int tof;
	char hostname[256];
/*	struct in_addr_t ip;*/
	if((WIN_HIGH < 23) || (WIN_STAT_LEN < 62) || (WIN_HELP_HIGH < 3) || (WIN_TEAMS_LEN < 5)){
		fprintf(stderr, "Wrong windows sizes\n");
		exit(-1);
	}

	if(argc == 3)
		server = atoi(argv[2]);	
	else if(argc == 2)
		server = STAND_PORT;	
	else{
		fprintf(stderr,"Необходимо указать номер порта сервера в параметрах\n");
		return 1;
	}

	adr.sin_family = AF_INET;
	adr.sin_port = htons(server);
	if ((adr.sin_addr.s_addr = inet_addr(argv[1])) == INADDR_NONE){
		printf("Ошибка\n");
		exit(-1);
	}
	gethostname(hostname, 255);
	pi.tof = 0;
	pi.map = NULL;
	pi.x = pi.y = 0;
	ti.players_num = 0;
	ti.players = NULL;
	gj.teams = NULL;
	gj.teams_num = 0;
	
	V = Start_scr;


	errno = 0;
	main_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (main_socket == -1){
		fprintf(stderr, "%s (%d): Сокет не был создан: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		exit(1);
	}

	errno = 0;
	/* connect! */
	if(connect(main_socket, (struct sockaddr *) &adr, sizeof(adr)) == -1){
		fprintf(stderr, "%s (%d): Не удалось установить соединение с сервером: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		exit(1);
	}

	errno =  0;
	fds = malloc(sizeof(struct pollfd));
	if(fds == NULL){
		fprintf(stderr, "%s (%d): Структура не была создана: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		exit(1);
	}

	fds[0].fd = main_socket;
	fds[0].events = POLLIN | POLLERR | POLLPRI;
	fds[0].revents = 0;

	initscr();	
	win_status = newwin(WIN_HIGH, WIN_STAT_LEN, 0, 0);
	win_teams = newwin(WIN_HIGH, WIN_TEAMS_LEN, 0, WIN_STAT_LEN);
	win_help = newwin(WIN_HELP_HIGH, WIN_STAT_LEN + WIN_TEAMS_LEN, WIN_HIGH, 0);

	signal(SIGINT, end_prog);
	signal(SIGPIPE, channel_closed);

	start_color();	
	init_pair(STAND_C, COLOR_WHITE, COLOR_BLACK);
	init_pair(INV_C, COLOR_BLACK, COLOR_WHITE);
	init_pair(BACK_C, COLOR_WHITE, COLOR_CYAN);
	init_pair(CH_C, COLOR_BLACK, COLOR_YELLOW);
	init_pair(CURS_C, COLOR_BLACK, COLOR_GREEN);
	init_pair(ATTEN_C, COLOR_WHITE, COLOR_RED);
	curs_set(0);

	keypad(win_status, true);
	keypad(win_teams, true);
	keypad(win_help, true);

	gj.teams_num = 0;
	gj.teams = NULL;
	
	/* Чтение списка команд */
	read_teams();	

	
	for(;;) switch(V){
		case Start_scr:
			noecho();
			raw();
			wclear(win_status);
			wclear(win_teams);
			wclear(win_help);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wbkgd(win_teams, COLOR_PAIR(BACK_C));
			wbkgd(win_help, COLOR_PAIR(STAND_C));

			wattron(win_status, COLOR_PAIR(INV_C));
			wattron(win_teams, COLOR_PAIR(INV_C));
			wattron(win_help, COLOR_PAIR(INV_C));

			box(win_status, 0, 0);
			box(win_teams, 0, 0);
			box(win_help, 0, 0);

			wattron(win_status, COLOR_PAIR(CH_C));

			prt_center_win(win_status, " Create team ", 8);
			prt_center_win(win_status, "     Exit    ", 9);

			wattron(win_teams, COLOR_PAIR(BACK_C));
			prt_center_win(win_teams, "    Team names   ", 1);

			upd_teams();
			wrefresh(win_help);

			clear_socket();
			V = Status_scr;
		break;

		case  Status_scr:
			/* List of options */
			tof = 1;
			curs_st = 0;
			curs_teams = 0;
			help_upd(ARR_USE, 2, STAND_C);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
				if(fds[0].revents > 0){
					syncro(&tof);
					continue;
				}
				for(i = 0; i < 2; i++){
					wmove(win_status, 8 + i, (getmaxx(win_status) - 13) / 2);
					if(i == curs_st){
						wattron(win_status, COLOR_PAIR(CURS_C));
						waddch(win_status, '>');
					}
					else{
						wattron(win_status, COLOR_PAIR(INV_C));
						waddch(win_status, ' ');
					}
				}
				switch(z = wgetch(win_status)){
					case KEY_UP:
						if(curs_st)
							curs_st--;
					break;
					case KEY_DOWN:
						if(!curs_st)
							curs_st++;
					break;
					case KEY_RIGHT:
						if(gj.teams_num){
							V = Team_scr;
							wmove(win_status, 8 + curs_st, (getmaxx(win_status) - 13) / 2);
							wattron(win_status, COLOR_PAIR(INV_C));
							waddch(win_status, ' ');
							tof = 0;
						}
					break;
					case KEY_ENTER:
						wmove(win_status, 8 + curs_st, (getmaxx(win_status) - 13) / 2);
						wattron(win_status, COLOR_PAIR(INV_C));
						waddch(win_status, ' ');
						tof = 0;
						switch(curs_st){
							case 0:
								V = Team_create;
							break;
							case 1:
								V = Stop;
							break;
						}
					break;
					case ESC:
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				wrefresh(win_status);
			}
		break;

		case Team_scr:
			/* List of teams */
			tof = 1;
			curs_st = 0;
			curs_teams = 0;
			teams_page = 0;

			help_upd(ARR_USE, 2, STAND_C);
			upd_teams();
			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
				if(fds[0].revents > 0){
					syncro(&tof);
					continue;
				}
				for(i = 0; i < MIN(WIN_HIGH - 3, gj.teams_num - teams_page * (WIN_HIGH - 3)); i++){
					wmove(win_teams, 2 + i, 1);
					if(i == curs_teams){
						wattron(win_teams, COLOR_PAIR(CURS_C));
						waddch(win_teams, '>');
					}
					else{
						wattron(win_teams, COLOR_PAIR(INV_C));
						waddch(win_teams, ' ');
					}
				}
				switch(wgetch(win_teams)){
					case KEY_UP:
						if(curs_teams)
							curs_teams--;
						else if(teams_page){
							teams_page--;
							curs_teams = 0;
							upd_teams();
						}
					break;
					case KEY_DOWN:
						if(curs_teams < MIN(WIN_HIGH - 4, gj.teams_num - teams_page * (WIN_HIGH - 3) - 1))
							curs_teams++;
						else if(teams_page < gj.teams_num / (WIN_HIGH - 3)){
							teams_page++;
							curs_teams = 0;
							upd_teams();
						}
					break;
					case KEY_LEFT:
						wmove(win_teams, 2 + curs_teams, 1);
						wattron(win_teams, COLOR_PAIR(INV_C));
						waddch(win_teams, ' ');
						V = Status_scr;
						tof = 0;
					break;
					case KEY_ENTER:
						wmove(win_teams, 2 + curs_teams, 1);
						wattron(win_teams, COLOR_PAIR(INV_C));
						waddch(win_teams, ' ');
						tof = 0;
						V = Team_join;	
					break;
					case ESC:
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				wrefresh(win_teams);
			}
		break;

		case Team_create:
			/* Process of team creation */
			i = 0;
			tof = 1;
			help_upd(ARR_USE, 2, STAND_C);

			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "Do you want to create your own team?", 8);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
				if(fds[0].revents > 0){
					syncro(&tof);
					continue;
				}
				wattron(win_status, COLOR_PAIR(i == 0 ? CURS_C : CH_C));
				wmove(win_status, 13, 20);
				wprintw(win_status, "%s", "YES");

				wattron(win_status, COLOR_PAIR(i == 1 ? ATTEN_C : CH_C));
				wmove(win_status, 13, WIN_STAT_LEN - 23);
				wprintw(win_status, "%s", "NO");

				switch(wgetch(win_status)){
					case KEY_LEFT:
						if(i)
							i--;
					break;
					case KEY_RIGHT:
						if(i != 1)
							i++;
					break;
					case KEY_ENTER:
						if(i)
							V = Start_scr;
						else{
							wclear(win_status);
							wbkgd(win_status, COLOR_PAIR(BACK_C));
							wattron(win_status, COLOR_PAIR(INV_C));
							box(win_status, 0, 0);
							/* Название команды */
							wattron(win_status, COLOR_PAIR(BACK_C));
							prt_center_win(win_status, "Enter team name", 8);
							wattron(win_status, COLOR_PAIR(STAND_C));
							mvwprintw(win_status, 13, 1, "%60s", "");
							curs_set(1);
							fflush(stdin);
							echo();
							cbreak();
							mvwgetnstr(win_status, 13, 1, buf, 61);
							raw();
							noecho();
							fflush(stdin);
							curs_set(0);
							z = 0;
							for(i = 0; (i < strlen(buf)) && !z; i++){
								if((buf[i] == ' ') || (buf[i] == '\n') || (buf[i] == '\t'))
									z = 1;
							}
							if((strlen(buf) > 60)){
								help_upd(TOO_MANY_SYMB, 2, ATTEN_C);
								sleep(2);
								tof = 0;
								V = Team_create;
								continue;
							}
							if(z){
								help_upd(CANNOT_USE, 2, ATTEN_C);
								sleep(2);
								tof = 0;
								V = Team_create;
								continue;
							}
							
							strcpy(ti.team_name, buf);
							wclear(win_status);
							wbkgd(win_status, COLOR_PAIR(BACK_C));
							wattron(win_status, COLOR_PAIR(INV_C));
							box(win_status, 0, 0);
							wattron(win_status, COLOR_PAIR(BACK_C));
							prt_center_win(win_status, "Enter participants number (<= 1000)", 8);
							wattron(win_status, COLOR_PAIR(STAND_C));
							mvwprintw(win_status, 13, (WIN_STAT_LEN - 4) / 2, "%4s", "");
							curs_set(1);
							fflush(stdin);
							echo();
							cbreak();
							mvwgetnstr(win_status, 13, (WIN_STAT_LEN - 4) / 2, buf, 5);
							raw();
							noecho();
							fflush(stdin);
							curs_set(0);
								
							if((strlen(buf) > 4) || ((z = atoi(buf)) == 0) || (z > 1000)){
								help_upd(W_F, 2, ATTEN_C);
								sleep(3);
								tof = 0;
								V = Team_create;
								continue;	
							}
							
							/*teams+*/
							signal(SIGINT, sigint_wait);
							j = 1;
							write(main_socket, &j, sizeof(int));
							j = strlen(ti.team_name) + 1;
							write(main_socket, &j, sizeof(int));
							write(main_socket, ti.team_name, j);
							write(main_socket, &z, sizeof(int));
							j = strlen(hostname) + 1;
							write(main_socket, &j, sizeof(int));
							write(main_socket, hostname, j);
							
							if(sig){
								tof = 0;
								V = Stop;
								continue;
							}
							signal(SIGINT, end_prog);
							if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(main_socket);
								V = Stop;
								tof = 0;
								continue;
							}
								
							switch(i){
								case 0:
									ti.tof = 1;
									ti.players_num = 0;
									ti.players_max = z;
									ti.players = NULL;
									V = Waiting_team;
								break;
								case 1:
									/* Server stop */
									channel_closed();
									V = Stop;
								break;
								case 2:
									ti.tof = 1;
									ti.players_num = 0;
									ti.players_max = z;
									ti.players = NULL;
									read_teams();
									upd_teams();
									V = Waiting_team;
								break;
								case 8:
									/* Team exists */
									help_upd(TEAM_EXISTS, 2, ATTEN_C);
									sleep(3);
									V = Team_create;
								break;
								default:
									help_upd(UNDEF_ERR, 2, ATTEN_C);
									sleep(3);
									V = Stop;
								break;
							}
						}
						tof = 0;
					break;
					case ESC:
						tof = 0;
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				wrefresh(win_status);
			}	

			
			
		break;

		case Team_join:
			/* Process of team join */
			i = 0;
			tof = 1;
			help_upd(ARR_USE, 2, STAND_C);
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);
			
			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "Do you want to join", 8);
			sprintf(buf, "%s ?", gj.teams[curs_teams + teams_page * (WIN_HIGH - 3)]);
			prt_center_win(win_status, buf, 9);
			
			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
				if(fds[0].revents > 0){
					syncro(&tof);
					continue;
				}
				wattron(win_status, COLOR_PAIR(i == 0 ? CURS_C : INV_C));
				wmove(win_status, 13, 20);
				wprintw(win_status, "%s", "YES");

				wattron(win_status, COLOR_PAIR(i == 1 ? ATTEN_C : INV_C));
				wmove(win_status, 13, WIN_STAT_LEN - 23);
				wprintw(win_status, "%s", "NO");

				switch(wgetch(win_status)){
					case KEY_LEFT:
						if(i)
							i--;
					break;
					case KEY_RIGHT:
						if(i != 1)
							i++;
					break;
					case KEY_ENTER:
						if(i)
							V = Start_scr;
						else{
							V = Waiting_game;
							wclear(win_status);
							wbkgd(win_status, COLOR_PAIR(BACK_C));
							wattron(win_status, COLOR_PAIR(INV_C));
							box(win_status, 0, 0);
											
							wattron(win_status, COLOR_PAIR(BACK_C));
							prt_center_win(win_status, "Enter your nickname", 8);
							
							wattron(win_status, COLOR_PAIR(STAND_C));
							
							mvwprintw(win_status, 13, 1, "%60s", "");
							curs_set(1);
							fflush(stdin);
							echo();
							cbreak();
							mvwgetnstr(win_status, 13, 1, buf, 61);
							raw();
							noecho();
							fflush(stdin);
							curs_set(0);
							tof = 0;
							for(i = 0; (i < strlen(buf)) && !tof; i++){
								if((buf[i] == ' ') || (buf[i] == '\n') || (buf[i] == '\t'))
									tof = 1;
							}
							if((strlen(buf) > 60)){
								help_upd(TOO_MANY_SYMB, 2, ATTEN_C);
								sleep(2);
								V = Team_create;
								tof = 0;
								continue;
							}
							if(tof){
								help_upd(CANNOT_USE, 2, ATTEN_C);
								sleep(2);
								V = Team_create;
								tof = 0;
								continue;
							}
							strcpy(pi.player_name, buf);
							strcpy(pi.team_name, gj.teams[curs_teams + teams_page * (WIN_HIGH - 3)]);
							/* player+ */
							signal(SIGINT, sigint_wait);
							j = 2;
							write(main_socket, &j, sizeof(int));
							j = strlen(pi.team_name) + 1;
							write(main_socket, &j, sizeof(int));
							write(main_socket, pi.team_name, j);
							j = strlen(pi.player_name) + 1;
							write(main_socket, &j, sizeof(int));
							write(main_socket, pi.player_name, j);
							j = strlen(hostname) + 1;
							write(main_socket, &j, sizeof(int));
							write(main_socket, hostname, j);
							if(sig){
								tof = 0;
								V = Stop;
								continue;
							}
							signal(SIGINT, end_prog);
							
							if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(main_socket);	
								V = Stop;
								tof = 0;
								continue;
							}
							switch(i){
								case 0:
									pi.x = -1;
									pi.y = -1;
									pi.health = -1;
									pi.tof = 1;
									V = Waiting_game;
								break;
								case 1:
									/* Server stop */
									channel_closed();
								break;
								case 2:
									pi.x = -1;
									pi.y = -1;
									pi.health = -1;
									pi.tof = 1;
									read_teams();
									upd_teams();
									V = Waiting_game;
								break;
								case 5:
									/* Too many members */
									help_upd(TOO_MANY_MEMB, 2, ATTEN_C);
									sleep(3);
									V = Start_scr;
								break;
								case 6:
									/* Nick already exists */
									help_upd(NICK_EXISTS, 2, ATTEN_C);
									sleep(3);
									V = Team_join;
								break;
								case 7:
									/* Team deleted */
									help_upd(TEAM_DEL, 2, ATTEN_C);
									sleep(3);
									V = Start_scr;
								break;
								case 11:
									/* Game started */
									help_upd(GAME_STARTED, 2, ATTEN_C);
									sleep(3);
									V = Start_scr;
								break;
								case 12:
									/* Game finished */
									help_upd(GAME_FINISHED, 2, ATTEN_C);
									sleep(3);
									V = Start_scr;
								break;
								default:
									help_upd(UNDEF_ERR, 2, ATTEN_C);
									sleep(3);
									V = Stop;
								break;
							}
				
						}
						tof = 0;
					break;
					case ESC:
						tof = 0;
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				wrefresh(win_status);
			}

			
		break;

		case Waiting_game:
			/* Member waiting */
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			wattron(win_help, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "Team:", 6);
			prt_center_win(win_status, pi.team_name, 7);
			prt_center_win(win_status, "Nickname:", 8);
			prt_center_win(win_status, pi.player_name, 9);

			wattron(win_status, COLOR_PAIR(CH_C));
			prt_center_win(win_status, "     Exit    ", 12);

			wattron(win_status, COLOR_PAIR(CURS_C));
			wmove(win_status, 12, (getmaxx(win_status) - 13) / 2);
			waddch(win_status, '>');

			upd_teams();
			wrefresh(win_help);

			tof = 1;
			help_upd(ARR_USE, 2, STAND_C);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
	    	    if(fds[0].revents > 0){
					if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
						fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
							__FILE__, __LINE__ - 2,  strerror(errno));
						close(main_socket);
						V = Stop;
						tof = 0;
						continue;
					}
			
					switch(i){
						case 1:
							/* Server stop */
							channel_closed();
						break;
						case 2:
							/* Teams update */
							read_teams();
							upd_teams();
							V = Waiting_game;
						break;
						case 3:
							/* Game start */
							tof = 0;
							V = Game;
						break;
						case 7:
							/* Team deleted */
							tof = 0;
							V = Start_scr;
						break;
						default:
							tof = 0;
							help_upd(UNDEF_ERR, 2, ATTEN_C);
							sleep(3);
							V = Stop;
						break;
					}
					continue;
				}

				switch(z = wgetch(win_status)){
					case KEY_ENTER:
						tof = 0;
						V = Stop;
					break;
					case ESC:
						tof = 0;
						send_del();
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				wrefresh(win_status);
			}
		break;
	
		case Waiting_team:
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			wattron(win_help, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "Team:", 6);
			prt_center_win(win_status, ti.team_name, 7);

			wattron(win_status, COLOR_PAIR(CH_C));

			prt_center_win(win_status, "  Start game ", 9);
			prt_center_win(win_status, "   Members   ", 10);
			prt_center_win(win_status, "     Exit    ", 11);

			upd_teams();
			wrefresh(win_help);

			tof = 1;
			curs_st = 0;
			help_upd(ARR_USE, 2, STAND_C);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
	    	    if(fds[0].revents > 0){
					if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
						fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
							__FILE__, __LINE__ - 2,  strerror(errno));
						close(main_socket);
						V = Stop;
						tof = 0;
						continue;
					}
			
					switch(i){
						case 1:
							/* Server stop */
							channel_closed();
						break;
						case 2:
							/* Teams update */
							read_teams();
							upd_teams();
							V = Waiting_team;
						break;
						case 3:
							/* Game start */
							tof = 0;
							ti.if_start = 1;
							V = Game_status;
						break;
						case 9:
							read_players();
							V = Waiting_team;
						break;
						default:
							tof = 0;
							help_upd(UNDEF_ERR, 2, ATTEN_C);
							sleep(3);	
							V = Stop;
						break;
					}
					continue;
				}
				
				for(i = 0; i < 3; i++){
					wmove(win_status, 9 + i, (getmaxx(win_status) - 13) / 2);
					if(i == curs_st){
						wattron(win_status, COLOR_PAIR(CURS_C));
						waddch(win_status, '>');
					}
					else{
						wattron(win_status, COLOR_PAIR(INV_C));
						waddch(win_status, ' ');
					}
				}
				switch(z = wgetch(win_status)){
					case KEY_UP:
						if(curs_st)
							curs_st--;
					break;
					case KEY_DOWN:
						if(curs_st < 2)
							curs_st++;
					break;
					case KEY_ENTER:
						tof = 0;
						switch(curs_st){
							case 0:
								signal(SIGINT, sigint_wait);
								j = 5;
								write(main_socket, &j, sizeof(int));
								j = strlen(ti.team_name) + 1;
								write(main_socket, &j, sizeof(int));
								write(main_socket, ti.team_name, j);
								if(sig){
									tof = 0;
									V = Stop;
									continue;
								}
								signal(SIGINT, end_prog);
								ti.if_start = 1;
								V = Game_status;
							break;
							case 1:
								V = Members;
							break;
							case 2:
								V = Stop;
							break;
						}
					break;
					case ESC:
						tof = 0;
						send_del();
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				
				wrefresh(win_status);
			}
		break;

		case Game_status:
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			wattron(win_help, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "Team:", 6);
			prt_center_win(win_status, ti.team_name, 7);

			wattron(win_status, COLOR_PAIR(CH_C));

			prt_center_win(win_status, "  Stop game  ", 9);
			prt_center_win(win_status, "   Members   ", 10);
			prt_center_win(win_status, "     Exit    ", 11);

			wrefresh(win_help);

			tof = 1;
			curs_st = 0;
			help_upd(ARR_USE, 2, STAND_C);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
	    	    if(fds[0].revents > 0){
					if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
						fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
							__FILE__, __LINE__ - 2,  strerror(errno));
						close(main_socket);
						V = Stop;
					}
			
					switch(i){
						case 1:
							/* Server stop */
							channel_closed();
						break;
						case 2:
							/* Teams update */
							read_teams();
							upd_teams();
							V = Game_status;
						break;
						case 4:
							/* Game stop */
							tof = 0;
							V = Winner;
						break;
						case 9:
							read_players();
							V = Game_status;
						break;
						default:
							tof = 0;
							help_upd(UNDEF_ERR, 2, ATTEN_C);
							sleep(3);	
							V = Stop;
						break;
					}
					continue;
				}
				
				for(i = 0; i < 3; i++){
					wmove(win_status, 9 + i, (getmaxx(win_status) - 13) / 2);
					if(i == curs_st){
						wattron(win_status, COLOR_PAIR(CURS_C));
						waddch(win_status, '>');
					}
					else{
						wattron(win_status, COLOR_PAIR(INV_C));
						waddch(win_status, ' ');
					}
				}
				switch(z = wgetch(win_status)){
					case KEY_UP:
						if(curs_st)
							curs_st--;
					break;
					case KEY_DOWN:
						if(curs_st < 2)
							curs_st++;
					break;
					case KEY_ENTER:
						tof = 0;
						switch(curs_st){
							case 0:
								V = Start_scr;
								signal(SIGINT, sigint_wait);
								j = 6;
								write(main_socket, &j, sizeof(int));
								j = strlen(ti.team_name) + 1;
								write(main_socket, &j, sizeof(int));
								write(main_socket, ti.team_name, j);
								if(sig){
									tof = 0;
									V = Stop;
									continue;
								}
								signal(SIGINT, end_prog);
							break;
							case 1:
								V = Members;
							break;
							case 2:
								V = Stop;
							break;
						}
					break;
					case ESC:
						tof = 0;
						send_del();
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				
				wrefresh(win_status);
			}

		break;

		case Members:
			players_page = 0;
			upd_teams();
			wrefresh(win_help);
			upd_players();

			tof = 1;
			curs_st = 0;
			help_upd(ARR_USE, 2, STAND_C);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
	    	    if(fds[0].revents > 0){
					if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
							fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
								__FILE__, __LINE__ - 2,  strerror(errno));
							close(main_socket);
							V = Stop;
							tof = 0;
							continue;
						}
			
					switch(i){
						case 1:
							/* Server stop */
							channel_closed();
						break;
						case 2:
							/* Teams update */
							read_teams();
							upd_teams();
							V = Waiting_game;
						break;
						case 4:
							/* Game stop */
							tof = 0;
							V = Winner;
						break;
						case 9:
							read_players();
							upd_players();
							V = Members;
						break;
						default:
							tof = 0;
							help_upd(UNDEF_ERR, 2, ATTEN_C);
							sleep(3);	
							V = Stop;
						break;
					}
					continue;
				}
				
				for(i = 0; i < 2; i++){
					wmove(win_status, 17 + i, (getmaxx(win_status) - 13) / 2);
					if(i == curs_st){
						wattron(win_status, COLOR_PAIR(CURS_C));
						waddch(win_status, '>');
					}
					else{
						wattron(win_status, COLOR_PAIR(INV_C));
						waddch(win_status, ' ');
					}
				}
				switch(z = wgetch(win_status)){
					case KEY_LEFT:
						if(players_page){
							players_page--;
							upd_players();
						}
					break;
					case KEY_RIGHT:
						if(players_page < ti.players_num / (WIN_HIGH - 13)){
							players_page++;
							upd_players();
						}
					break;

					case KEY_UP:
						if(curs_st)
							curs_st--;
					break;
					case KEY_DOWN:
						if(!curs_st)
							curs_st++;
					break;
					case KEY_ENTER:
						tof = 0;
						switch(curs_st){
							case 0:
								if(ti.if_start == 0)
									V = Waiting_team;
								else if(ti.if_start == 1)
									V = Game_status;
							break;
							case 1:
								V = Stop;
							break;
						}
					break;
					case ESC:
						tof = 0;
						send_del();
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				
				wrefresh(win_status);
			}

		break;

		case You_win:
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "YOU WIN", 6);
			wrefresh(win_status);
			sleep(5);
			free_map();
			V = Start_scr;
		break;

		case You_lose:
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(BACK_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			wattron(win_status, COLOR_PAIR(BACK_C));
			prt_center_win(win_status, "YOU LOSE", 6);
			wrefresh(win_status);
			sleep(5);
			free_map();
			V = Start_scr;
		break;

		case Game:
			wclear(win_status);
			wbkgd(win_status, COLOR_PAIR(STAND_C));
			wattron(win_status, COLOR_PAIR(INV_C));
			box(win_status, 0, 0);

			tof = 1;
			curs_st = 0;
			help_upd(ARR_USE, 1, STAND_C);
			prt_center_win(win_help, GAME_USE, 2);
			wrefresh(win_help);

			while(tof){
				halfdelay(1);
				poll(fds, 1, 100);
	    	    if(fds[0].revents > 0){
					if((n_read = read(main_socket, &i, sizeof(int))) != sizeof(int)){
							fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
								__FILE__, __LINE__ - 2,  strerror(errno));
							close(main_socket);
							V = Stop;
							tof = 0;
							continue;
						}
			
					switch(i){
						case 1:
							/* Server stop */
							channel_closed();
						break;
						case 2:
							/* Teams update */
							read_teams();
							upd_teams();
							V = Game;
						break;
						case 4:
							/* Game stop */
							tof = 0;
							V = Winner;
						break;
						case 7:
							/* Team deleted */
							V = Start_scr;
							tof = 0;
							help_upd(TEAM_DEL, 2, ATTEN_C);
						break;
						case 10:
							/* Update game */
							read_game();
							upd_game();
							V = Game;
						break;
						case 11:
							/* You win */
							tof = 0;
							V = You_win;
							pi.tof = 0;
						break;
						case 12:
							/* You lose */
							tof = 0;
							V = You_lose;
							pi.tof = 0;
						break;
						default:
							printf("i = %d", i);
							sleep(2);
							tof = 0;
							help_upd(UNDEF_ERR, 2, ATTEN_C);
							sleep(3);	
							V = Stop;
						break;
					}
					continue;
				}
				z = 0;
				j = 10;
				switch(z = wgetch(win_status)){
					case KEY_DC:
						/* Kit */
						j++;	
					case KEY_ENTER:
						/* Weapon */
						j++;	
					case KEY_IC:
						/* Bomb */
						j++;	
					case KEY_DOWN:
						/* v */
						j++;	
					case KEY_RIGHT:
						/* > */
						j++;	
					case KEY_UP:
						/* ^ */
						j++;	
					case KEY_LEFT:
						/* < */
						j++;
						z = 1;
						signal(SIGINT, sigint_wait);
						write(main_socket, &j, sizeof(int));
						j = strlen(pi.team_name) + 1;
						write(main_socket, &j, sizeof(int));
						write(main_socket, pi.team_name, j);
						j = strlen(pi.player_name) + 1;
						write(main_socket, &j, sizeof(int));
						write(main_socket, pi.player_name, j);
						if(sig){
							tof = 0;
							V = Stop;
							continue;
						}
						signal(SIGINT, end_prog);
					break;
					case ESC:
						tof = 0;
						send_del();
						V = Start_scr;
					break;
					case CTRL_C:
					case CTRL_D:
						tof = 0;
						V = Stop;
					break;
				}
				
				wrefresh(win_status);
			}
		break;
		
		case Stop:
			end_prog(win_status, win_teams, win_help);
		break;
	}
	return 100;
}
