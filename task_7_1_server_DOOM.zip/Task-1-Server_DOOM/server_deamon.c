#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#define stand_prog_name "server"
int main(int argc, char * argv[]){
	close(0);
	if(fork() == 0){
		strcpy(argv[0], stand_prog_name);
		execv(stand_prog_name, argv);
		printf("Не удалось запустить сервер\n");
		exit(-1);
	}
	exit(0);
}
