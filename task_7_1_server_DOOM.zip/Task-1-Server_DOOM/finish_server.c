#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#define stand_pid_file "pid_test"
int pid;
FILE * pid_file;
int main(){
	if((pid_file = fopen(stand_pid_file, "r")) == NULL){
		fprintf(stderr, "%s (%d): Не удалось открыть файл: %s\n", __FILE__ , __LINE__ - 2,  strerror(errno));
		exit(-1);
	}
	fscanf(pid_file, "%d", &pid);
	kill(pid, SIGINT);
	fclose(pid_file);
}
