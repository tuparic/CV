#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <poll.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>

#define MAX_QUEUE 5
#define MEM_INC_SIZE 8
#define BUF_SIZE 256
#define stand_map_file "map_test"
#define stand_journal_file "journal_test"
#define stand_pid_file "pid_test"
#define MIN(X, Y) ((X) > (Y)? (Y) : (X))
#define MAX(X, Y) ((X) > (Y)? (X) : (Y))

struct Game_info{
	int map_x, map_y;
	char ** map;
	int items_num;
	int ** items;
	int initial_health, hit_value, recharge_duration,
		mining_time, stay_health_drop, movement_health_drop,
		step_standard_delay, moratory_duration;
};

struct Player_info{
	int x, y, health;
	int channel_num;
	char host_name[256];
	int bombs_num;
	int status;
	time_t weapon, bomb;
	char player_name[61];
};

struct Team_info{
	int if_start;
	struct timeval delay_time;
	char start_date[20], end_date[20], winner_name[61];
	int channel_num;
	char host_name[256];
	time_t start;
	int players_num;
	int players_max;
	char team_name[61];
	struct Player_info * team_member;
	int * items;
	int bombs_num;
	int ** bombs; 
	char ** map;
};

struct Game_journal{
	struct Team_info * teams;
	int teams_num;
};

int main_socket;
int clients;
char buf[BUF_SIZE], buf1[256];
struct pollfd *fds, * temp_fds; 
ssize_t n_read;
struct Game_journal gj;
struct Game_info gi;
FILE *map_file, *journal_file, *pid_file;
int sig = 0;
char journal_file_name[255];
/* Освобождение памяти выделенной под команду */
void free_team(int team){
	int i;
	if(gj.teams[team].map != NULL)
		for(i = 0; i < gi.map_y; i++)
			free(gj.teams[team].map[i]);
	free(gj.teams[team].map);
	free(gj.teams[team].items);
	for(i = 0; i < gj.teams[team].bombs_num; i++)
		free(gj.teams[team].bombs[i]);
	free(gj.teams[team].bombs);

	gj.teams[team].map = NULL;
	gj.teams[team].items = NULL;
	gj.teams[team].bombs = NULL;
	gj.teams[team].bombs_num = 0;
}

/* Освобождение памяти выделенной под информацию об игре */
void free_gi(){
	int i;
	for(i = 0; i < gi.map_y; i++)
		free(gi.map[i]);
	free(gi.map);
	for(i = 0; i < gi.items_num; i++)
		free(gi.items[i]);
	free(gi.items);
}

/* Освобождение памяти выделенной под журнал */
void free_journal(){
	int i;
	for(i = 0; i < gj.teams_num; i++){
		free_team(i);
		free(gj.teams[i].team_member);
	}
	free(gj.teams);
}

void sigint_wait(){
	sig = 1;
}

/* Завершение работы сервера */
void stop_server(){
	int i, j = 1;
	signal(SIGINT, sigint_wait);
	for(i = 1; i <= clients; i++)
		if(fds[i].fd != -1){
			write(fds[i].fd, &j, sizeof(int));
			close(fds[i].fd);
		}
	free_journal();
	free_gi();
	free(fds);
	exit(0);
}

/* Преодразование системного времени к читабельному формату */
void settime(struct tm *u, char * str){
	char s[40];
	int i;
	for (i = 0; i<40; i++) s[i] = 0;
	strftime(s, 40, "%d.%m.%Y %H:%M:%S", u);
	strcpy(str, s);
}

/* Чтение файла с картой */
void read_map_file(char * file_name){
	int i, j;
	FILE * input;
	char symb;	

	free_gi();

	if((input = fopen(file_name, "r+")) == NULL){
		fprintf(stderr, "%s (%d): Не удалось открыть файл: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	fscanf(input, "Map %dx%d\n", &gi.map_x, &gi.map_y);

	/*printf("map_x = %d\nmap_y = %d\n", gi.map_x, gi.map_y);*/
	if((gi.map = calloc(gi.map_y, sizeof(char *))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	for(i = 0; i < gi.map_y; i++)
		if((gi.map[i] = calloc(gi.map_x, sizeof(char))) == NULL){
			fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			stop_server();
		}
	for(i=0; i < gi.map_y; i++){
		for(j = 0; j < gi.map_x; j++){
			fscanf(input, "%c", &symb);
			if((symb != '#') && (symb != ' ')){
				fprintf(stderr, "Wrong map file\n");
				exit(-1);
			}
			gi.map[i][j] = symb == '#'? 1: 0;	
			/*printf("%d", gi.map[i][j]);*/
		}
		fscanf(input, "%c", &symb);
		/*printf("\n");*/
	}

	fscanf(input, "initial_health = %d\n", &gi.initial_health);
	fscanf(input, "hit_value = %d\n", &gi.hit_value);
	fscanf(input, "recharge_duration = %d\n", &gi.recharge_duration);
	fscanf(input, "mining_time = %d\n", &gi.mining_time);
	fscanf(input, "stay_health_drop = %d\n", &gi.stay_health_drop);
	fscanf(input, "movement_health_drop = %d\n", &gi.movement_health_drop);
	fscanf(input, "step_standard_delay = %d\n", &gi.step_standard_delay);
	fscanf(input, "moratory_duration = %d\n", &gi.moratory_duration);

	/*printf("initial_health = %d\n", gi.initial_health);
	printf("hit_value = %d\n", gi.hit_value);
	printf("recharge_duration = %d\n", gi.recharge_duration);
	printf("mining_time = %d\n", gi.mining_time);
	printf("stay_health_drop = %d\n", gi.stay_health_drop);
	printf("movement_health_drop = %d\n", gi.movement_health_drop);
	printf("step_standard_delay = %d\n", gi.step_standard_delay);
	printf("moratory_duration = %d\n", gi.moratory_duration);*/

	fscanf(input, "items_num = %d\n", &gi.items_num);
	/*printf("items_num = %d\n", gi.items_num);*/
	if((gi.items = calloc(gi.items_num, sizeof(int *))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	for(i = 0; i < gi.items_num; i++){
		if((gi.items[i] = calloc(3, sizeof(int))) == NULL){
			fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			stop_server();
		}
		fscanf(input, "%d %d %d\n", &gi.items[i][0], &gi.items[i][1], &gi.items[i][2]);
		/*printf("%d %d %d\n", gi.items[i][0], gi.items[i][1], gi.items[i][2]);*/
	}

	fclose(input);
}



/* Запись журнала в файл */
void write_journal_file(){
	int i, j, z;
	FILE * output;
	if((output = fopen(journal_file_name, "w")) == NULL){
		fprintf(stderr, "%s (%d): Не удалось открыть файл: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	
	for(i=0; i < gj.teams_num; i++){
		fprintf(output, "team %s\n", gj.teams[i].team_name);
		switch(gj.teams[i].if_start){
			case 0:
			fprintf(output, "%s", "\tGame started\n");
			break;
			case 1:
			fprintf(output, "%s", "\tPlaying\n");
			break;
			case 2:
			fprintf(output, "%s", "\tGame finished\n");
			break;
		}
		fprintf(output, "\t   Start date:%s\n", gj.teams[i].start_date);
		fprintf(output, "\t     End date:%s\n", gj.teams[i].end_date);
		fprintf(output, "\t  Winner name:%s\n", gj.teams[i].winner_name);
		fprintf(output, "\t    Host name:%s\n", gj.teams[i].host_name);
		fprintf(output, "\t   Status:%s\n", gj.teams[i].channel_num == -1? "offline" :"online");

		fprintf(output, "\tTeam members:\n");

		for(j = 0; j < gj.teams[i].players_num; j++){
			fprintf(output, "\t\t     name:%s\n", gj.teams[i].team_member[j].player_name);
			fprintf(output, "\t\t   status:%s\n", gj.teams[i].team_member[j].channel_num == -1? "offline" :"online");
			fprintf(output, "\t\t        x:%d\n", gj.teams[i].team_member[j].x);
			fprintf(output, "\t\t        y:%d\n", gj.teams[i].team_member[j].y);
			fprintf(output, "\t\t   health:%d\n", gj.teams[i].team_member[j].health);
			fprintf(output, "\t\thost name:%s\n\n", gj.teams[i].team_member[j].host_name);
		}
	}
	fclose(output);
}

/* Передача списка команд клиенту */
void write_teams(int num){
	int i, tek;
	/*printf("\tSending teams info to client %d\n", num);*/
	signal(SIGINT, sigint_wait);
	write(fds[num].fd, & gj.teams_num, sizeof(int));
	for(i=0; i < gj.teams_num; i++){
		tek = strlen(gj.teams[i].team_name) + 1;
		write(fds[num].fd, &tek, sizeof(int));
		write(fds[num].fd, gj.teams[i].team_name, tek);
	}
	if(sig)
		stop_server();
	signal(SIGINT, stop_server);
	/*printf("\tSent successfully\n");*/
}

/* Передача списка игроков клиенту */
void send_players(int num, int team){
	int i, j;
	/*printf("\tSending players info to client %d\n", num);*/
	j = 9;
	signal(SIGINT, sigint_wait);
	write(fds[num].fd, &j, sizeof(int));
	write(fds[num].fd, & gj.teams[team].players_num, sizeof(int));
	for(i=0; i < gj.teams[team].players_num; i++){
		j = strlen(gj.teams[team].team_member[i].player_name) + 1;
		write(fds[num].fd, &j, sizeof(int));
		write(fds[num].fd, gj.teams[team].team_member[i].player_name, j);
		write(fds[num].fd, &gj.teams[team].team_member[i].x, sizeof(int));
		write(fds[num].fd, &gj.teams[team].team_member[i].y, sizeof(int));
		write(fds[num].fd, &gj.teams[team].team_member[i].health, sizeof(int));
	}
	if(sig)
		stop_server();
	signal(SIGINT, stop_server);
	/*printf("\tSent successfully\n");*/
}

/* Передача информации об игре клиентам по номеру команды */
void send_game_info(int team){
	time_t timer;
	int i, j, z;
	int fd, team_fd;
	char symb;
	/*printf("Sending game info to team %s\n", gj.teams[team].team_name);*/
	timer = time(NULL);
	if(timer == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}

	for(i = 0; i < gi.items_num; i++)
		if(gj.teams[team].items[i]){
			if(gj.teams[team].map[gi.items[i][1]][gi.items[i][0]] == 0)
				gj.teams[team].map[gi.items[i][1]][gi.items[i][0]] = 4;
		}	
	
	send_players(gj.teams[team].channel_num, team);
	for(i = 0; i < gj.teams[team].players_num; i++){
		/*if((fd = fds[gj.teams[team].team_member[i].channel_num].fd) == -1)*/
		if((j = gj.teams[team].team_member[i].channel_num) == -1)
			continue;

		fd = fds[j].fd;
		/*printf("Sending game info to %s\n", gj.teams[team].team_member[i].player_name);*/
		j = 10;
		signal(SIGINT, sigint_wait);
		write(fd, &j, sizeof(int));
		gj.teams[team].map[gj.teams[team].team_member[i].y][gj.teams[team].team_member[i].x] = 3;
		j = MIN(gj.teams[team].team_member[i].x + 10, gi.map_x) - MAX(0, gj.teams[team].team_member[i].x - 10); 
		write(fd, &j, sizeof(int));
		j = MIN(gj.teams[team].team_member[i].y + 10, gi.map_y) - MAX(0, gj.teams[team].team_member[i].y - 10); 
		write(fd, &j, sizeof(int));
		for(j = MAX(0, gj.teams[team].team_member[i].y - 10); j < MIN(gj.teams[team].team_member[i].y + 10, gi.map_y); j++)
			for(z = MAX(0, gj.teams[team].team_member[i].x - 10); z < MIN(gj.teams[team].team_member[i].x + 10, gi.map_x); z++)
				write(fd, &gj.teams[team].map[j][z], sizeof(char));
		write(fd, &gj.teams[team].team_member[i].health, sizeof(int));
		write(fd, &gj.teams[team].team_member[i].bombs_num, sizeof(int));
		if(gj.teams[team].team_member[i].bomb)
			j = (int)(gi.mining_time - (timer - gj.teams[team].team_member[i].bomb));
		else
			j = 0;
		write(fd, &j, sizeof(int));
		if(gj.teams[team].team_member[i].weapon)
			j = (int)(gi.recharge_duration - (timer - gj.teams[team].team_member[i].weapon));
		else
			j = 0;
		write(fd, &j, sizeof(int));
		if(gj.teams[team].start)
			j = (int)(gi.moratory_duration - (timer - gj.teams[team].start));
		else
			j = 0;
		write(fd, &j, sizeof(int));
		gj.teams[team].map[gj.teams[team].team_member[i].y][gj.teams[team].team_member[i].x] = 2;
		if(sig)
			stop_server();
		signal(SIGINT, stop_server);
	}

	for(i = 0; i < gi.items_num; i++)
		if(gj.teams[team].items[i]){
			if(gj.teams[team].map[gi.items[i][1]][gi.items[i][0]] == 4)
				gj.teams[team].map[gi.items[i][1]][gi.items[i][0]] = 0;
		}	
	/*printf("Sent successfully\n");*/
}

/* Номер команды с ником */
int team_n(char * str){
	int i;
	for(i = 0; i < gj.teams_num; i++){
		if(strcmp(str, gj.teams[i].team_name) == 0)
			return(i);
	}
	return(-1);
}

/* Номер игрока с ником */
int player_n(char * str, int team){
	int i;
	for(i = 0; i < gj.teams[team].players_num; i++){
		if(strcmp(str, gj.teams[team].team_member[i].player_name) == 0)
			return(i);
	}
	return(-1);
}

/* Добавить команду */
void add_team(char * str, int channel, char * host, int max){
	int i, j;
	gj.teams_num++;
	if((gj.teams = realloc(gj.teams, gj.teams_num * sizeof(struct Team_info))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка realloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	gj.teams[gj.teams_num - 1].if_start = 0;
	strcpy(gj.teams[gj.teams_num - 1].start_date, "*none");
	strcpy(gj.teams[gj.teams_num - 1].end_date, "*none");
	strcpy(gj.teams[gj.teams_num - 1].winner_name, "*none");
	
	gj.teams[gj.teams_num - 1].players_num = 0;
	gj.teams[gj.teams_num - 1].channel_num = channel;
	strcpy(gj.teams[gj.teams_num - 1].host_name, host);
	gj.teams[gj.teams_num - 1].players_max = max;
	strcpy(gj.teams[gj.teams_num - 1].team_name, str);
	gj.teams[gj.teams_num - 1].team_member = NULL;
	gj.teams[gj.teams_num - 1].map = NULL;
	gj.teams[gj.teams_num - 1].items = NULL;
	gj.teams[gj.teams_num - 1].bombs = NULL;
	gj.teams[gj.teams_num - 1].bombs_num = 0;
	
	write_journal_file();
	j = 2;
	for(i = 1; i <= clients; i++){
		if(fds[i].fd > 0){
			write(fds[i].fd, &j, sizeof(int));
			write_teams(i);
		}
	}
}

/* Добавить игрока */
void add_player(char * str, int team, int channel, char * host){
	int j;
	gj.teams[team].players_num++;
	if((gj.teams[team].team_member = realloc(gj.teams[team].team_member, (gj.teams[team].players_num) * sizeof(struct Player_info))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка realloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	/*gj.teams[team].team_member[gj.teams[team].players_num - 1] = malloc(sizeof(struct Player_info));*/
	strcpy(gj.teams[team].team_member[gj.teams[team].players_num - 1].player_name, str);
	gj.teams[team].team_member[gj.teams[team].players_num - 1].x = -1;
	gj.teams[team].team_member[gj.teams[team].players_num - 1].y = -1;
	gj.teams[team].team_member[gj.teams[team].players_num - 1].health = -1;
	gj.teams[team].team_member[gj.teams[team].players_num - 1].channel_num = channel;
	strcpy(gj.teams[team].team_member[gj.teams[team].players_num - 1].host_name, host);
	
	write_journal_file();
	send_players(gj.teams[team].channel_num, team);
	
}

/* Очистить сокет */
void clear_socket(int num){
	while((poll(&fds[num], 1, 5) > 0) && fds[num].revents && read(fds[num].fd, buf, BUF_SIZE) > 0);
}

/* Начало игры для команды с номером team */
void start_game(int team){
	struct tm *u;
	char *f;
	time_t timer;
	int i, j, z, r, tek;
	int free;
	/*printf("\tGame starting for team %s\n", gj.teams[team].team_name);*/
	timer = time(NULL);
	if(timer == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	u = localtime(&timer);
	settime(u, gj.teams[team].start_date);
	if(gettimeofday(&gj.teams[team].delay_time, NULL) == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	gj.teams[team].start = timer;
	gj.teams[team].if_start = 1;
	gj.teams[team].bombs_num = 0;
	gj.teams[team].bombs = NULL;
	if((gj.teams[team].items = calloc(gi.items_num, sizeof(int))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	for(i = 0; i < gi.items_num; i++)
		gj.teams[team].items[i] = 1;
	free = 0;
	if((gj.teams[team].map = calloc(gi.map_y, sizeof(char * ))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	for(i = 0; i < gi.map_y; i++){
		if((gj.teams[team].map[i] = calloc(gi.map_x, sizeof(char))) == NULL){
			fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			stop_server();
		}
		for(j = 0; j < gi.map_x; j++){
			gj.teams[team].map[i][j] = gi.map[i][j];
			if(gj.teams[team].map[i][j] == 0)
				free++;
		}
	}
	
	for(i = 0; i < gj.teams[team].players_num; i++){
		if(gj.teams[team].team_member[i].channel_num == -1)
			continue;
		j = 3;
		signal(SIGINT, sigint_wait);
		write(fds[gj.teams[team].team_member[i].channel_num].fd, &j, sizeof(int));	
		if(sig)
			stop_server();
		signal(SIGINT, stop_server);
		r = rand() % free;
		free--;
		tek = 0;
		for(j = 0; j < gi.map_y; j++)
			for(z = 0; z < gi.map_x; z++){
				if(tek > r)
					break;
				if(gj.teams[team].map[j][z] == 0){
					if(tek == r){
						gj.teams[team].team_member[i].x = z;
						gj.teams[team].team_member[i].y = j;
						gj.teams[team].map[j][z] = 2;
						gj.teams[team].team_member[i].health = gi.initial_health;
						gj.teams[team].team_member[i].bombs_num = 10;
						gj.teams[team].team_member[i].status = 0;
						gj.teams[team].team_member[i].weapon = 0;
						gj.teams[team].team_member[i].bomb = 0;
					}
					tek++;
				}
			}
	}
	send_game_info(team);
	write_journal_file();
	/*printf("Game started\n");	*/
}

/* Окончание игры для команды с номером team */
void stop_game(int team){
	struct tm *u;
	char *f;
	time_t timer;
	int i, j, z, max, num;
	/*printf("\tGame stopping for team %s\n", gj.teams[team].team_name);*/
	gj.teams[team].channel_num = -1;
	
	timer = time(NULL);
	if(timer == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	u = localtime(&timer);
	settime(u, gj.teams[team].end_date);

	j = -1;
	max = 0;
	num = 0;
	gj.teams[team].if_start = 2;
	for(i = 0; i < gj.teams[team].players_num; i++){
		if(gj.teams[team].team_member[i].channel_num == -1)
			continue;
		if(gj.teams[team].team_member[i].health > max){
			j = i;
			max = gj.teams[team].team_member[i].health;
			num = 1;
		}	
		else if(gj.teams[team].team_member[i].health == max)
			num++;
	}

	if((j != -1) && (num == 1))
		sprintf(gj.teams[team].winner_name, "%s", gj.teams[team].team_member[j].player_name);
	else
		sprintf(gj.teams[team].winner_name, "no winner");
	
	for(i = 0; i < gj.teams[team].players_num; i++){
		if(gj.teams[team].team_member[i].channel_num == -1)
			continue;
		z = i == j ? 11 : 12;
		signal(SIGINT, sigint_wait);
		write(fds[gj.teams[team].team_member[i].channel_num].fd, &z, sizeof(int));
		gj.teams[team].team_member[i].channel_num = -1;
		if(sig)
			stop_server();
		signal(SIGINT, stop_server);
	}
	free_team(team);
	write_journal_file();
	/*printf("Game stopped\n");*/
}

/* Удаление команды */
void del_team(int team){
	struct tm *u;
	char *f;
	time_t timer;
	int i, j;
	/*printf("\tDeleting team %s\n", gj.teams[team].team_name);*/
	gj.teams[team].channel_num = -1;
	timer = time(NULL);
	u = localtime(&timer);

	if(gj.teams[team].if_start == 0){
		settime(u, gj.teams[team].start_date);
		settime(u, gj.teams[team].end_date);
		sprintf(gj.teams[team].winner_name, "no winner");
		j = 7;
		signal(SIGINT, sigint_wait);
		for(i = 0; i < gj.teams[team].players_num; i++)
			if(gj.teams[team].team_member[i].channel_num != -1){
				write(fds[gj.teams[team].team_member[i].channel_num].fd, &j, sizeof(int));
				gj.teams[team].team_member[i].channel_num = -1;
			}	
		gj.teams[team].if_start = 2;
		if(sig)
			stop_server();
		signal(SIGINT, stop_server);
	}
	else if(gj.teams[team].if_start == 1){
		stop_game(team);
	}
	free_team(team);
	write_journal_file();
	/*printf("\tTeam deleted\n");*/
}

/* Удаление игрока */
void del_player(int team, int player){
	/*printf("\tDeleting player %s from team %s\n", gj.teams[team].team_member[player].player_name, gj.teams[team].team_name);*/
	if((gj.teams[team].team_member[player].x != -1) && (gj.teams[team].team_member[player].y != -1)){
		gj.teams[team].map[gj.teams[team].team_member[player].y][gj.teams[team].team_member[player].x] = 0;
	}
	gj.teams[team].team_member[player].channel_num = -1;
	gj.teams[team].team_member[player].x = -1;
	gj.teams[team].team_member[player].y = -1;
	gj.teams[team].team_member[player].health = -1;

	write_journal_file();
	send_players(gj.teams[team].channel_num, team);
	/*printf("\tPlayer deleted\n");*/
}

void new_bomb(int team, int x, int y){
	gj.teams[team].bombs_num++;
	if((gj.teams[team].bombs = realloc(gj.teams[team].bombs, gj.teams[team].bombs_num * sizeof(int *))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка realloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	if((gj.teams[team].bombs[gj.teams[team].bombs_num - 1] = calloc(3, sizeof(int))) == NULL){
		fprintf(stderr, "%s (%d): Ошибка calloc: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	gj.teams[team].bombs[gj.teams[team].bombs_num - 1][0] = x;
	gj.teams[team].bombs[gj.teams[team].bombs_num - 1][1] = y;
	gj.teams[team].bombs[gj.teams[team].bombs_num - 1][2] = 1;
}

int if_bomb(int team, int x, int y){
	int i;
	for(i = 0; i < gj.teams[team].bombs_num; i++)
		if((gj.teams[team].bombs[i][0] == x) && (gj.teams[team].bombs[i][1] == y))
			return(i);
	return(-1);
}

void upd_games(void){
	int i, j, z, tek, bomb_timer, weapon_timer, min, num, coord_x, coord_y;
	time_t timer;
	struct timeval timer_ms;
	timer = time(NULL);
	/*printf("***** time = %ld\n", timer);*/
	if(timer == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	if(gettimeofday(&timer_ms, NULL) == -1){
		fprintf(stderr, "%s (%d): Не удалось определить время: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	for(i = 0; i < gj.teams_num; i++){
		if(gj.teams[i].if_start != 1)
			continue;
		if((long)(timer_ms.tv_sec * 1000 + timer_ms.tv_usec / 1000) - (long)(gj.teams[i].delay_time.tv_sec * 1000 + gj.teams[i].delay_time.tv_usec / 1000) < gi.step_standard_delay)
			continue;
		gj.teams[i].delay_time.tv_sec = timer_ms.tv_sec;
		gj.teams[i].delay_time.tv_usec = timer_ms.tv_usec;
		if(gj.teams[i].start)
			if(timer - gj.teams[i].start > gi.moratory_duration){
				gj.teams[i].start = 0;
			}

		for(j = 0; j < gj.teams[i].players_num; j++){
			if(gj.teams[i].team_member[j].channel_num == -1)
				continue;
			if(gj.teams[i].team_member[j].bomb)
				if(timer - gj.teams[i].team_member[j].bomb > gi.mining_time){
					gj.teams[i].team_member[j].bomb = 0;
					new_bomb(i, gj.teams[i].team_member[j].x, gj.teams[i].team_member[j].y);	
				}
			if(gj.teams[i].team_member[j].weapon)
				if(timer - gj.teams[i].team_member[j].weapon > gi.recharge_duration){
					gj.teams[i].team_member[j].weapon = 0;
				}
			if(gj.teams[i].team_member[j].bomb){
				gj.teams[i].team_member[j].status = 0;
				gj.teams[i].team_member[j].health -= gi.stay_health_drop;
				continue;
			}

			switch(gj.teams[i].team_member[j].status){
				case 0:
					gj.teams[i].team_member[j].health -= gi.stay_health_drop;
				break;
				case 11: /*<*/
				case 12: /*^*/
				case 13: /*>*/
				case 14: /*v*/
					coord_x = gj.teams[i].team_member[j].x;
					coord_y = gj.teams[i].team_member[j].y;
					num = gj.teams[i].team_member[j].status;
					if(gj.teams[i].map[coord_y + ((num - 1) % 2) * (num - 13)][coord_x + (num % 2) * (num - 12)] == 0){
						gj.teams[i].map[coord_y][coord_x] = 0;
						gj.teams[i].team_member[j].x += (num % 2) * (num - 12);
						gj.teams[i].team_member[j].y += ((num - 1) % 2) * (num - 13);
						gj.teams[i].map[gj.teams[i].team_member[j].y][gj.teams[i].team_member[j].x] = 2;
						gj.teams[i].team_member[j].health -= gi.movement_health_drop;
						if ((tek = if_bomb(i, gj.teams[i].team_member[j].x, gj.teams[i].team_member[j].y)) != -1){
							gj.teams[i].team_member[j].health -= gi.hit_value;
							gj.teams[i].bombs[tek][2] = 0;
						}
					}
					else
						gj.teams[i].team_member[j].health -= gi.stay_health_drop;
				break;
				case 15: /*Bomb*/
					if(gj.teams[i].team_member[j].bombs_num){
						gj.teams[i].team_member[j].bomb = timer;
						gj.teams[i].team_member[j].health -= gi.stay_health_drop;
						gj.teams[i].team_member[j].bombs_num--;
					}
				break;
				case 16: /*Weapon*/
					/*printf("///////////////////WEAPON player %s\n", gj.teams[i].team_member[j].player_name);*/
					if(gj.teams[i].team_member[j].weapon || gj.teams[i].start)
						break;
					coord_x = gj.teams[i].team_member[j].x;
					coord_y = gj.teams[i].team_member[j].y;
					min = gi.map_x > gi.map_y? gi.map_x : gi.map_y;						
					num = 0;
					/* Поиск минимума */
					for(z = 0; z < gj.teams[i].players_num; z++){
						if(j == z)
							continue;
						if((gj.teams[i].team_member[z].x != coord_x) && (gj.teams[i].team_member[z].y != coord_y))
							continue;
						if(gj.teams[i].team_member[z].x != coord_x){
							if(abs(gj.teams[i].team_member[z].x - coord_x) < min){
								num = 1;
								min = abs(gj.teams[i].team_member[z].x - coord_x);	
							}
							else if(abs(gj.teams[i].team_member[z].x - coord_x) ==  min)
								num++;
						}
						if(gj.teams[i].team_member[z].y != coord_y){
							if(abs(gj.teams[i].team_member[z].y - coord_y) < min){
								num = 1;
								min = abs(gj.teams[i].team_member[z].y - coord_y);	
							}
							else if(abs(gj.teams[i].team_member[z].y - coord_y) ==  min)
								num++;
						}
					}
					if(num == 0)
						break;
					/*printf("num = %d\n", num);*/
					tek = rand() % num + 1;
					num = 0;
					for(z = 0; z < gi.items_num; z++){
						if(j == z)
							continue;
						if((gj.teams[i].team_member[z].x != coord_x) && (gj.teams[i].team_member[z].y != coord_y))
							continue;
						if(gj.teams[i].team_member[z].x != coord_x)
							if(abs(gj.teams[i].team_member[z].x - coord_x) == min){
								num++;
								if(num == tek)
									break;
							}
						if(gj.teams[i].team_member[z].y != coord_y)
							if(abs(gj.teams[i].team_member[z].y - coord_y) == min){
								num++;
								if(num == tek)
									break;
							}
					}
					/*printf("shoot at player '%s', min = %d\n", gj.teams[i].team_member[z].player_name, min);*/
					gj.teams[i].team_member[z].health -= gi.hit_value / min;
					gj.teams[i].team_member[j].health -= gi.stay_health_drop;
					gj.teams[i].team_member[j].weapon = timer;
				break;
				case 17: /*Kit*/
					for(z = 0; z < gi.items_num; z++){
						if(!gj.teams[i].items[z])
							continue;
						if((gj.teams[i].team_member[j].x == gi.items[z][0]) && (gj.teams[i].team_member[j].y == gi.items[z][1])){
							gj.teams[i].team_member[j].health += gi.items[z][2];
							gj.teams[i].items[z] = 0;
							if(gj.teams[i].team_member[j].health >= 1000)
								gj.teams[i].team_member[j].health = 999;
							break;
						}
					}
				break;
			}
			gj.teams[i].team_member[j].status = 0;
		}

		for(j = 0; j < gj.teams[i].players_num; j++){
			if(gj.teams[i].team_member[j].channel_num == -1)
				continue;
			if(gj.teams[i].team_member[j].health < 0){
				z = 12;
				signal(SIGINT, sigint_wait);
				write(fds[gj.teams[i].team_member[j].channel_num].fd, &z, sizeof(int));
				del_player(i, j);
				if(sig)
					stop_server();
				signal(SIGINT, stop_server);
			}
		}
		send_game_info(i);	
	}
	write_journal_file();
}



int main(int argc, char *argv[]){
	int instr_num, port, max_clients, events, temp_socket, i, j, z, tek, tek1, mf_FLAG = 0, jf_FLAG = 0, err_FLAG = 0;
	int cl_x, cl_y;
	struct sockaddr_in adr;
	/* Анализ параметров командной строки */
	if(argc < 2){
		fprintf(stderr,"Необходимо указать номер порта в параметрах\n");
		return -1;
	}
	else{
		port = atoi(argv[1]);
		for(i = 2; i < argc; i++){
			if(argv[i][0] == '-'){
				if(strcmp(argv[i], "-mf") == 0){
					if(mf_FLAG || (i + 1 >= argc))
						err_FLAG = 1;
					mf_FLAG = i;
				}
				else if(strcmp(argv[i], "-jf") == 0){
					if(jf_FLAG || (i + 1 >= argc))
						err_FLAG = 1;
					jf_FLAG = i;
				}
			}
		}
		if(err_FLAG){
			fprintf(stderr, "Неверный формат командной строки\n");
			exit(-1);
		}	
	}

	srand(time(NULL));
	
	/* Инициализация */
	gi.map = NULL;
	gi.items = NULL;
	gi.items_num = 0;
	gi.map_x = gi.map_y = 0;
	gj.teams = NULL;
	gj.teams_num = 0;

	if(jf_FLAG)
		strcpy(journal_file_name, argv[jf_FLAG + 1]);
	else
		strcpy(journal_file_name, stand_journal_file);
		
	write_journal_file();
	/* Открытие файла с картой */
	if(mf_FLAG)
		read_map_file(argv[mf_FLAG + 1]);
	else	
		read_map_file(stand_map_file);

	/* Открытие файла с PID сервера и запись в него */
	if((pid_file = fopen(stand_pid_file, "w")) == NULL){
		fprintf(stderr, "%s (%d): Не удалось открыть файл: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	
	fprintf(pid_file, "%d", getpid());
	fclose(pid_file);
	/*printf("PID записан\n");*/

	signal(SIGINT, stop_server);
	adr.sin_family = AF_INET;
	adr.sin_port = htons(port);
	adr.sin_addr.s_addr = INADDR_ANY;

	errno = 0;
	main_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (main_socket == -1){
		fprintf(stderr, "%s (%d): Сокет не был создан: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}

	errno = 0;
	if(bind(main_socket, (struct sockaddr *) &adr, sizeof(adr)) == -1){
		fprintf(stderr, "%s (%d): Не удалось привязать к адресу: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}
	
	errno = 0;
	if(listen(main_socket, MAX_QUEUE) == -1){
		fprintf(stderr, "%s (%d): Не удалось установить сокет в режим TCP: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}

	max_clients = MEM_INC_SIZE;
	clients = 0;

	errno =  0;
	fds = malloc(sizeof(struct pollfd) * (max_clients + 1));
	if(fds == NULL){
		fprintf(stderr, "%s (%d): Структура не была создана: %s\n",
			__FILE__, __LINE__ - 2,  strerror(errno));  
		stop_server();
	}

	fds[0].fd = main_socket;
	fds[0].events = POLLIN | POLLERR | POLLPRI;
	fds[0].revents = 0;


	for(;;){
		upd_games();
		events = poll(fds, clients + 1, 100);
		if(events == -1){
			fprintf(stderr, "%s (%d): Проблемы с poll: %s\n",
				__FILE__, __LINE__ - 2,  strerror(errno));  
			stop_server();
		}

		if(events == 0)
			continue;

		/*printf("Events = %d\n", events);*/

		if(fds[0].revents){
			temp_socket = accept(main_socket, NULL, NULL);
			if(temp_socket == -1){
				fprintf(stderr, "%s (%d): Не удалось принять: %s\n",
					__FILE__, __LINE__ - 2,  strerror(errno));  
				stop_server();
			}
			clients++;
			/*printf("Клиент %d подсоединился\n", clients);*/
			if(clients >= max_clients){
				max_clients += MEM_INC_SIZE;
				temp_fds = fds;
				fds = realloc(fds, sizeof(struct pollfd) * (max_clients + 1));
				if(fds == NULL){
					fprintf(stderr, "%s (%d): Ошибка realloc: %s\n",
						__FILE__, __LINE__ - 2,  strerror(errno));  
					free(temp_fds);
					stop_server();
				}
			}

			fds[clients].fd = temp_socket;	
			fds[clients].events = POLLIN | POLLERR | POLLPRI | POLLHUP;
			fds[clients].revents = 0;
			fds[0].revents=0;
			write_teams(clients);
			/*printf("\tЖурнал передан клиенту %d\n", clients);*/
		}	
		for(i = 1; i <= clients; i++){
			if(fds[i].revents){
				n_read = read(fds[i].fd, &instr_num, sizeof(int));
				if(n_read == 0){
					/*printf("Клиент %d отсоединился\n",i);*/
					close(fds[i].fd);
					fds[i].fd = -1;
					fds[i].revents = 0;
					continue;
				}
				if(n_read != sizeof(int)){
					fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
						__FILE__, __LINE__ - 2,  strerror(errno));
					close(fds[i].fd);
					fds[i].fd = -1;
					fds[i].revents = 0;
					continue;
				}
				if(n_read > 0){
					/* Информация о командах */
					switch(instr_num){
						case -1:
							close(fds[i].fd);
							fds[i].fd = -1;
							fds[i].revents = 0;
						break;
						case 0:
							/* teams */
							write_teams(i);
						break;
						case 1:
							/*printf("\tClient %d wants to add team\n", i);*/
							/* teams+ */
							/* Размер строки */
							if((n_read = read(fds[i].fd, &j, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Чтение строки */
							if((n_read = read(fds[i].fd, buf, j)) != j){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/*printf("\t\t%s\n", buf);*/
							if((j = team_n(buf)) != -1){
								/* Team exists */
								clear_socket(i);
								j = 8;
								signal(SIGINT, sigint_wait);
								write(fds[i].fd, &j, sizeof(int));
								if(sig)
									stop_server();
								signal(SIGINT, stop_server);
								fds[i].revents = 0;
								continue;
							}
							/* players_max */
							if((n_read = read(fds[i].fd, &z, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* host name*/
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((n_read = read(fds[i].fd, buf1, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Success */
							/*printf("\tAdding team %d\n", i);*/
							j = 0;
							clear_socket(i);
							signal(SIGINT, sigint_wait);
							write(fds[i].fd, &j, sizeof(int));
							if(sig)
								stop_server();
							signal(SIGINT, stop_server);
							add_team(buf, i, buf1, z);
							/*write_teams(i);*/
							/*printf("\tAdded successfully\n");*/
						break;
	
						case 2:
							/* member+ */
							/* Длина строки */
							if((n_read = read(fds[i].fd, &j, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Чтение строки */
							if((n_read = read(fds[i].fd, buf, j)) != j){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) == -1){
								/* Team deleted */
								j = 7;
								clear_socket(i);
								signal(SIGINT, sigint_wait);
								write(fds[i].fd, &j, sizeof(int));
								if(sig)
									stop_server();
								signal(SIGINT, stop_server);
								fds[i].revents = 0;
								continue;
							}
							if(gj.teams[z].if_start != 0 ){
								/* Game started/finished */
								j = 10 + gj.teams[z].if_start;
								clear_socket(i);
								signal(SIGINT, sigint_wait);
								write(fds[i].fd, &j, sizeof(int));
								if(sig)
									stop_server();
								signal(SIGINT, stop_server);
								fds[i].revents = 0;
								continue;
							}
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* host name*/
							if((n_read = read(fds[i].fd, &tek1, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((n_read = read(fds[i].fd, buf1, tek1)) != tek1){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((tek = player_n(buf, z)) != -1){
								/* Nick exists */
								j = 6;
								signal(SIGINT, sigint_wait);
								write(fds[i].fd, &j, sizeof(int));
								if(sig)
									stop_server();
								signal(SIGINT, stop_server);
								fds[i].revents = 0;
								continue;
							}
							if(gj.teams[z].players_num >= gj.teams[z].players_max){
								/* Too many members */
								j = 5;
								signal(SIGINT, sigint_wait);
								write(fds[i].fd, &j, sizeof(int));
								if(sig)
									stop_server();
								signal(SIGINT, stop_server);
								fds[i].revents = 0;
								continue;
							}
							/* Success */
							j = 0;
							signal(SIGINT, sigint_wait);
							write(fds[i].fd, &j, sizeof(int));
							if(sig)
								stop_server();
							signal(SIGINT, stop_server);
							add_player(buf, z, i, buf1);
							/*write_teams(i);*/
						break;	
						case 3:
							/* teams- */
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) != -1){
								del_team(z);
								continue;
							}
						break;
						case 4:
							/* player- */
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/*printf("tek = %d\n", tek);*/
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) == -1){
								continue;
							}
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((tek = player_n(buf, z)) != -1){
								del_player(z, tek);
							}
						break;
						case 5:
							/* Game start */
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) != -1){
								start_game(z);
								continue;
							}
						break;
						case 6:
							/* Game stop */
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) != -1){
								stop_game(z);
								continue;
							}
						break;
						case 11: /*<*/
						case 12: /*^*/
						case 13: /*>*/
						case 14: /*v*/
						case 15: /* Bomb */
						case 16: /* Weapon */
						case 17: /* Kit */	
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((z = team_n(buf)) == -1)
								continue;
							/* Длина строки */
							if((n_read = read(fds[i].fd, &tek, sizeof(int))) != sizeof(int)){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							/* Строка */
							if((n_read = read(fds[i].fd, buf, tek)) != tek){
								fprintf(stderr, "%s (%d): Ошибка при чтении из сокета: %s\n",
									__FILE__, __LINE__ - 2,  strerror(errno));
								close(fds[i].fd);
								fds[i].fd = -1;
								fds[i].revents = 0;
								continue;
							}
							if((tek = player_n(buf, z)) == -1)
								continue;
							gj.teams[z].team_member[tek].status = instr_num;
						break;
						default:
							fprintf(stderr, "%s (%d): Ошибка при передаче данных\n",
									__FILE__, __LINE__ - 2);
							close(fds[i].fd);
							fds[i].fd = -1;
							fds[i].revents = 0;
							continue;
						break;
					}
				}
			}
			fds[i].revents = 0;
		}
	}
	return 100;
}
