#include <ncurses.h>
int key;
int main(){
	halfdelay(50);
	initscr();
	raw();
	while((key = getch()) != 27){
		printw("key = %d\n", key);
		printw("Enter key\n");
	}
	endwin();
}
