#include <stdio.h>
#include "list.h"
#include "tree.h"
#include <stdlib.h>
#include <string.h>
#include "colors.h"
#include <unistd.h>
words wd;
int error_FLAG;
int curi;
char* curlex; /* текущая лексема */
void getlex(); /* получает следующую лексему */
tree shell_instr();
tree process_list(); /* распознает команду и строит дерево */
tree pipeline(); /* распознает процесс в конвейере и строит дерево */
tree instr(); /* распознает команду и строит дерево */
tree base_instr(); /* распознает простую команду и строит дерево */

void error(); /* сообщает об ошибке в выражении и передает управление в начало функции main (точка begin) */


void clear_tree(tree *t){
	tree p = *t;
	char **r, **q;
	if(p == NULL) return;
	q = p -> argv;
	if(p -> psubcmd != NULL){
		clear_tree(&(p -> psubcmd));
	}
	if(p -> pipe != NULL){
		clear_tree(&(p -> pipe));
	}
	if(p -> next != NULL){
		clear_tree(&(p -> next));
	}
	r = q;
	if(q!=NULL){
		while(*q!=NULL){
			free(*q);
			q++;
		}
	}
	free(r);
	if(p -> infile != NULL) free(p -> infile); 
	if(p -> outfile != NULL) free(p -> outfile);
	free(*t);
	*t = NULL;
}

void make_shift(int n){
	while(n--)
		putc(' ', stderr);
}

void print_argv(char **p, int shift){
	char **q=p;
	if(p!=NULL){
		while(*p!=NULL){
			make_shift(shift);
			fprintf(stderr, "argv[%d]=%s\n",(int) (p-q), *p);
			p++;
		}
	}
}

/* printing tree */
void print_tree(tree t, int shift){
	char **p;
	if(t==NULL)
		return;
	p=t->argv;
	if(p!=NULL)
		print_argv(p, shift);
	else{
		make_shift(shift);
		fprintf(stderr, "psubshell\n");
	}
	make_shift(shift);
	if(t->infile==NULL)
		fprintf(stderr, "infile=NULL\n");
	else
		fprintf(stderr, "infile=%s\n", t->infile);
	make_shift(shift);
	if(t->outfile==NULL)
		fprintf(stderr, "outfile=NULL\n");
	else
		fprintf(stderr, "outfile=%s\n", t->outfile);
	make_shift(shift);
	fprintf(stderr, "append=%d\n", t->append);
	make_shift(shift);
	fprintf(stderr, "background=%d\n", t->backgrnd);
	make_shift(shift);
	fprintf(stderr, "type=%s\n", t->type==NXT?"NXT": t->type==OR?"OR": "AND" );
	make_shift(shift);
	if(t->psubcmd==NULL)
		fprintf(stderr, "psubcmd=NULL \n");
	else{
		fprintf(stderr, "psubcmd---> \n");
		print_tree(t->psubcmd, shift+5);
	}
	make_shift(shift);
	if(t->pipe==NULL)
		fprintf(stderr, "pipe=NULL \n");
	else{
		fprintf(stderr, "pipe---> \n");
		print_tree(t->pipe, shift+5);
	}
	make_shift(shift);
	if(t->next==NULL)
		fprintf(stderr, "next=NULL \n");
	else{
		fprintf(stderr, "next---> \n");
		print_tree(t->next, shift+5);
	}
}

void getlex(){
	if(curi < wd -> cur)
		curlex = (wd -> arr)[curi++];
	else
		curlex = NULL;
}

tree new_node(){
	tree p;
	p = (tree) malloc(sizeof(node));
	p -> argv = NULL;
	p -> infile = NULL;
	p -> outfile = NULL;
	p -> append = 0;
	p -> backgrnd = 0;
	p -> psubcmd = NULL;
	p -> pipe = NULL;
	p -> next = NULL;
	p -> type = NXT;
	return(p);
}



tree shell_instr(){
	tree p;
	getlex();
	p = process_list();
	return(p);
}
void set_backgrnd(tree * t){
	tree p = *t;
	if(p == NULL) return;
	p -> backgrnd = 1;
	if(p -> pipe != NULL){
		set_backgrnd(&(p -> pipe));
	}
	if(p -> next != NULL){
		set_backgrnd(&(p -> next));
	}
}

tree process_list(){
	tree p, q;
	p = pipeline();
	q = p;
	while ((!error_FLAG) && (curlex != NULL) && ((strcmp(curlex, "&") == 0) || (strcmp(curlex, ";") == 0))){
		if(strcmp(curlex, "&") == 0){
			getlex();
			set_backgrnd(&p);
			p -> next = pipeline();
			p = p -> next;
		}
		else{
			getlex();
			p -> next = pipeline();
			p = p -> next;
		}
	}
	return(q);
}

tree pipeline(){
	tree p, q;
	p = instr();
	q = p;
	while ((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, "|") == 0)){
		getlex();
		p -> pipe = instr();
		p = p -> pipe;
	}
	return(q);
}

tree instr(){
	tree p = NULL;
	if ((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, "(") == 0)){
		getlex();
		p = new_node();
		p ->  psubcmd = process_list();
		if((curlex == NULL) || (strcmp(curlex, ")") != 0))
			error();
		getlex();
		if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, "<") == 0)){
			getlex();
			if(curlex == NULL)
				error();
			p -> infile = calloc(strlen(curlex)+1, sizeof(char));
			strcpy(p -> infile, curlex);
			getlex();
		}
		if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, ">") == 0)){
			getlex();
			if(curlex == NULL)
				error();
			p -> outfile = calloc(strlen(curlex)+1, sizeof(char));
			strcpy(p -> outfile, curlex);
			getlex();
		}
		else if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, ">>") == 0)){
			getlex();
			if(curlex == NULL)
				error();
			p -> outfile = calloc(strlen(curlex)+1, sizeof(char));
			strcpy(p -> outfile, curlex);
			p -> append = 1;
			getlex();
		}
	}
	else if((curlex != NULL) && !error_FLAG)
		p = base_instr();
	return(p);
}

void add_lex(char *** argv){
	int i=0;
	if(*argv != NULL){
		for(; (*argv)[i] != NULL; i++);
		*argv = (char **)realloc(*argv, (i + 2) * sizeof(char *));
	}
	else
		*argv = (char **)calloc(i + 2, sizeof(char *));
	(*argv)[i] = (char *)calloc(strlen(curlex)+1, sizeof(char));
	strcpy((*argv)[i], curlex);
	(*argv)[i+1] = NULL;
}

tree base_instr(){
	tree p = new_node();
	if(curlex == NULL) 
		return(NULL);
	while((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, "<") != 0) && (strcmp(curlex, ">") != 0) && (strcmp(curlex, ">>") != 0) && (strcmp(curlex, "|") != 0) && (strcmp(curlex, "&") != 0) && (strcmp(curlex, ";") != 0) && (strcmp(curlex, "(") != 0) && (strcmp(curlex, ")") != 0)){
		add_lex(&(p -> argv));
		getlex();
	}
	if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, "<") == 0)){
		getlex();
		if(curlex == NULL)
			error();
		p -> infile = calloc(strlen(curlex)+1, sizeof(char));
		strcpy(p -> infile, curlex);
		getlex();
	}
	if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, ">") == 0)){
		getlex();
		if(curlex == NULL)
			error();
		p -> outfile = calloc(strlen(curlex)+1, sizeof(char));
		strcpy(p -> outfile, curlex);
		getlex();
	}
	else if((!error_FLAG) && (curlex != NULL) && (strcmp(curlex, ">>") == 0)){
		getlex();
		if(curlex == NULL)
			error();
		p -> outfile = calloc(strlen(curlex)+1, sizeof(char));
		strcpy(p -> outfile, curlex);
		p -> append = 1;
		getlex();
	}
	return(p);
}

void error(void){
	printf(B_RED_C "\nERROR IN TREE CREATING\n" STAND_C);
	fflush(stdout);
	while(getchar() != '\n');
	error_FLAG = 1;
}

tree build_tree(words w){
	char *inbuf, *outbuf;
	tree p = NULL;
	wd = w;
	error_FLAG = 0;
	curi = 0;
	p = shell_instr();
	if (curlex != NULL) 
		error();
	if(error_FLAG){
		clear_tree(&p);
		return(NULL);	
	}
	return(p);	
}
