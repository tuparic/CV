#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include <string.h>
#include <linux/limits.h>
#include <setjmp.h>
#include "colors.h"
jmp_buf begin;
int error_FLAG;
/*errors*/
int error_in_list(char * s1){
	printf(B_RED_C "ERROR IN LIST CREATING: %s\n" STAND_C, s1);
	fflush(stdout);
	while(getchar() != '\n');
	error_FLAG = 1;
    longjmp(begin,1);
}

/* Creates new list */
void new_list(words wd){
	wd -> size = wd -> cur = 0;
	wd -> arr = NULL;
}

/* Adds '\0' to the word and writes the resulting string to the end of the list */
void add_word(buf bf, words wd){
	if(bf -> cur > bf -> size - 1)
		if((bf -> arr = realloc(bf -> arr, (bf -> size +=1) * sizeof(*(bf -> arr)))) == NULL)
			error_in_list("Cannot extend buffer1");
	if(wd -> cur > wd -> size - 1)
		if((wd -> arr = realloc(wd -> arr, (wd -> size += list_elem_size) * sizeof(*(wd -> arr)))) == NULL)
			error_in_list("Cannot extend list2");

	(bf -> arr)[(bf -> cur)++] = '\0';
	if((bf -> arr = realloc(bf -> arr, bf -> size = bf -> cur)) == NULL)
		error_in_list("Cannot cut buffer3");
	
	(wd -> arr)[(wd -> cur)++] = bf -> arr;
	bf -> cur = 0;
}

/* Prints list to stdin */
void print_list(words wd){
	int i;
	if(wd -> arr == NULL) return;
	for(i = 0; i < wd -> cur; i++) 
		printf("%s\n", (wd -> arr)[i]);
}

/* Deletes list */
void del_list(words wd){
	int i;
	if(wd == NULL) return;
	if(wd -> arr == NULL) return;
	for(i = 0; i < wd -> cur; i++) 
		free((wd -> arr)[i]);
	free(wd -> arr);
	wd -> arr = NULL;
	wd -> size = wd -> cur = 0;
}

/* bubble sort of list */
void sort_list(words wd){
	int i, j;
	char * t;
	for(i = 0; i < wd -> cur; i++){
		for(j = 0; j < wd -> cur - 1 - i; j++){
			if(strcmp((wd -> arr)[j], (wd -> arr)[j+1]) > 0){
				t = (wd -> arr)[j];
				(wd -> arr)[j] = (wd -> arr)[j+1];
				(wd -> arr)[j+1] = t;
			}
		}
	}
}

/* 1 - if element c is in array p, else 0*/
int is_in(char c, char * p, int len){
	int i;
	for(i = 0; i < len; i++)
		if(c == p[i])
			return(1);
	return(0);
}

/* End of string */
void list_terminal(words wd){
	if(wd -> arr == NULL) return;
	if(wd -> arr > wd -> arr - 1)
		if((wd -> arr = realloc(wd -> arr, (wd -> size + 1) * sizeof(*(wd -> arr)))) == NULL)
			error_in_list("Cannot extend list");
	(wd -> arr)[wd -> cur] = NULL;
	if((wd -> arr = realloc(wd -> arr, (wd -> size = wd -> cur) * sizeof(*(wd -> arr)))) == NULL)
		error_in_list("Cannot cut list");
}

/* Creates new buffer */
void new_buf(buf bf){
	bf -> size = bf -> cur = 0;
	bf -> arr = NULL;
}

/* Adds symbol to buffer */
char add_sym(buf bf, char c){
	if(bf -> cur > bf -> size - 1)
		if((bf -> arr = realloc(bf -> arr, (bf -> size += buf_elem_size) * sizeof(*(bf -> arr)))) == NULL)
			error_in_list("Cannot extend buffer");
	(bf -> arr)[(bf -> cur)++] = c;
}

/* prints value of $-sequences to buf */
void value(char * s, char * buf){
	int t, i, j;
	if((strcmp(s, "$HOME") == 0) || (strcmp(s, "$SHELL") == 0) || (strcmp(s, "$USER") == 0)) strcpy(buf, getenv(&(s[1])));
	else if(strcmp(s, "$EUID") == 0){ 
		t = getuid();
		i = 1;
		while(t / i >= 10)
			i *= 10;
		for(j = 0;i > 0; j++, i/=10){
			buf[j] = '0' + (t / i);
			t = t % i;
		}
		buf[j] = '\0';
	}
}

/* prints value of $-sequences to the word */
int zam(char * s1, char * s2, int j){
	int i, t, l_s1 = strlen(s1), l_s2 = strlen(s2);
	char buf[PATH_MAX];
	value(s2, buf);
	if(strncmp(s1 + j, s2, l_s2) == 0){
		t = strlen(buf) - l_s2;
		if(t > 0){
			s1 = (char *) realloc(s1, (l_s1 + t) * sizeof(char));
			for(i = l_s1 + t; i >= l_s2 + j + t; i--)
				s1[i] = s1[i - t];
		}
		else if(t < 0){
			for(i = l_s2 + j + t; i <= l_s1 + t; i++)
				s1[i] = s1[i - t];
			s1 = (char *) realloc(s1, (l_s1 + t) * sizeof(char));
		}
		for(i = 0; i < strlen(buf); i++)
			s1[i+j] = buf[i];
		return(1);
	}
	return(0);
}

/* search for $-sequences */
void change(words wd){
	int i, j;
	char * t;
	for(i = 0; i < (wd -> cur); i++){
		for(j = 0; (wd -> arr)[i][j] != '\0'; j++){
			if((wd -> arr)[i][j] == '$'){
				if(zam((wd -> arr)[i], "$HOME", j));
				else if(zam((wd -> arr)[i], "$SHELL", j));
				else if(zam((wd -> arr)[i], "$USER", j));
				else if(zam((wd -> arr)[i], "$EUID", j));
			}
		}
	}
}


/* Printst list, number of elements and sorted list */
void out(words wd){
	change(wd);
	/*fprintf(stderr, "***************************************** Number of elements *****************************************\n");
	printf("%d\n", wd -> cur);*/
	fprintf(stderr, B_GREEN_C "\nMADE LIST\n" STAND_C);
	fflush(stderr);
	print_list(wd);
	/*sort_list(wd);
	fprintf(stderr, "********************************************* Sorted list ********************************************\n");
	print_list(wd);*/
}

/* Gets symbol from stdin*/
int getsym(){
	static char readbuf[readbuf_elem_size];
	static int curreadbuf = 0;
	static int n = 0;
	if(n == 0){
		if((n = read(0, readbuf, sizeof(readbuf))) <= 0)
			return(EOF);
		curreadbuf = 0;
	}
	return(--n, (unsigned char)readbuf[curreadbuf++]);
}

	char mas_symb_for_spec[] = {'<', '(', ')', ';'};
	int spec_num = 4;

	char mas_symb_for_double_spec[] = {'|', '&', '>'};
	int double_spec_num = 3;

	char mas_symb_for_separation[] = {EOF, '\n', ' ', '\t'};
	int separation_num = 4;


/* Creates list of words */
words list_make(int * end_FLAG){
	enum {Start, Word, Spec, One, Two, Newline, STOP} V;
	int c;
	int  one;

/* Флаг для кавычек */
	int quot_m_FLAG = 0, sh_FLAG = 0;
	
	buf bf; /* Pointer for buffer struct */
	words wd; /* Pointer for list of words struct */

	V = Start;
	c = getsym();
	error_FLAG = 0;
	setjmp(begin);
	if(error_FLAG){	
		del_list(wd);
		free(wd);
		free(bf);
		return(NULL);
	}
	if((wd = (words) malloc(sizeof(struct WORDS))) == NULL)
		error();
	new_list(wd);

	if((bf = (buf) malloc(sizeof(struct BUFFER))) == NULL)
		error();
	new_buf(bf);

	while(0 == 0) switch(V){
		case Start:
			if((c == ' ') || (c == '\t')) 
				c = getsym();
			else if((c == '\n') || (c == EOF)){
				if(c == EOF)
					printf("\n");
				list_terminal(wd);
				V = Newline;
			}
			else if(c == '#'){
				while((c = getsym()) != '\n');
				V = Start;
			}
			else if(is_in(c, mas_symb_for_spec, spec_num) && !sh_FLAG){
				new_buf(bf);
				add_sym(bf, c);
				V = Spec;
				c = getsym();
			}
			else if(is_in(c, mas_symb_for_double_spec, double_spec_num) && !sh_FLAG){
				new_buf(bf);
				add_sym(bf, c);
				V = One;
				one = c;
				c = getsym();
			}
			else {	
				quot_m_FLAG = 0;
				sh_FLAG = 0;
				new_buf(bf);
				V = Word;
			}
		break;
		
		case Word:
			if(!is_in(c, mas_symb_for_spec, spec_num) && !is_in(c, mas_symb_for_double_spec, double_spec_num) && !is_in(c, mas_symb_for_separation, separation_num) && (c != '#') || sh_FLAG || quot_m_FLAG){
				if((c == '\\') && !sh_FLAG){
					sh_FLAG = 1;
					c = getsym();
					V = Word;
				}
				else if((c == '"') && !sh_FLAG){
					quot_m_FLAG = !quot_m_FLAG;
					c = getsym();
					V = Word;
				}
				else{
					add_sym(bf, c);
					c = getsym();
					sh_FLAG = 0;	
					V = Word;
				}
			}
			else{
				V = Start;
				add_word(bf, wd);
			}
		break;
		
		case Spec:
			V = Start;
			add_word(bf, wd);
		break;

		case One:
			if(c == one){
				add_sym(bf, c);
				c = getsym();
				V = Two;
			
			}
			else{
				V = Start;
				add_word(bf, wd);
			}
		break;
		
		case Two:
			V = Start;
			add_word(bf, wd);
		break;
		
		case Newline:
			free(bf);
			*end_FLAG = c == EOF;
			return(wd);
		break;
		
	}
}
