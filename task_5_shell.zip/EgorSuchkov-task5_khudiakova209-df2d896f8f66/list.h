
#ifndef LIST_H
#define LIST_H

#define list_elem_size 16
#define buf_elem_size 16
#define readbuf_elem_size 16

struct WORDS{
	char ** arr;
	int size, cur;
};
typedef struct WORDS * words;

struct BUFFER{
	char * arr;
	int size, cur;
};
typedef struct BUFFER * buf;
/* Prints list to stdin */
void out(words);
/* Deletes list */
void del_list(words);
/* Creates list of words */
words list_make(int *);

#endif

