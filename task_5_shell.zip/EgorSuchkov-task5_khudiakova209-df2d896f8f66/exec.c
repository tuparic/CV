#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include "list.h"
#include "tree.h"
#include "colors.h"
#include "exec.h"
int execute_instr(tree, int, int, int);
void execute_pipeline(tree);
int exit_FLAG = 0;
int error_FLAG = 0;
void error_exec(){
	fflush(stderr);
	printf(B_RED_C "ERROR IN PROCESS EXECUTING\n" STAND_C);
	fflush(stdout);
}

int internal(char * s){
	if((strcmp(s, "cd") == 0) || (strcmp(s, "exit") == 0) || (strcmp(s, "pwd") == 0))
		return(1);
	return(0);
}

void printcwd(int f){
	char cwd[1024];
	getcwd(cwd, sizeof(cwd));
	write(f, cwd, strlen(cwd));	
	cwd[0] = '\n';
	cwd[1] = '\0';
	write(f, cwd, 2);
}

void back_proc(){
	int i, j;
	int status;
	for(i = 0; i < pidnum; i++){
		if(waitpid(backpid[i], &status, WNOHANG|WUNTRACED)!= 0){
			printf(L_BLUE_C "Backgrnd process with PID %d finished\n" STAND_C,backpid[i]);
			fflush(stdout); 
			if((!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status))) && !(WIFSIGNALED(status)))
				error_exec();	
			for(j = i+1; j < pidnum; j++)
				backpid[j-1] = backpid[j];
			backpid = realloc(backpid, (--pidnum) * sizeof(*backpid));
		}	
	}
}

int execute_instr(tree instr, int in, int out, int next_in){
	int fd, pid=0;
	if((instr -> argv == NULL) || !internal(instr -> argv[0])){
		if((pid = fork())==0){
			signal(SIGINT, SIG_DFL);
			free(backpid);
			backpid = NULL;
			pidnum = 0;
			if(instr -> backgrnd)
				signal(SIGINT, SIG_IGN);
			if(next_in)
				close(next_in);
			if(instr -> infile != NULL){
				if((fd = open(instr -> infile, O_RDONLY)) == -1){
					exit(-1);
				}
				dup2(fd, 0);
				close(fd);
			}
			else if(in){
				dup2(in, 0);
				close(in);
			}
			else if(instr -> backgrnd)
				close(0);
			
			if(instr -> outfile != NULL){
				if(instr -> append){
					if((fd = open(instr -> outfile, O_APPEND|O_RDWR|O_CREAT, 0666)) == -1)
						exit(-1);
				}
				else
					if((fd = open(instr -> outfile, O_CREAT|O_RDWR|O_TRUNC, 0666)) == -1)
						exit(-1);
				dup2(fd, 1);
				close(fd);
			}
			else if(out){
				dup2(out, 1);
				close(out);
			}
			if(instr -> psubcmd != NULL){
				execute_shell_instr(instr -> psubcmd);
				exit(0);
			}
			else if(instr -> argv != NULL)
				execvp(instr -> argv[0], instr -> argv);
			exit(-1);
		}
		else if(instr -> backgrnd){
			backpid = realloc(backpid, (++pidnum) * sizeof(*backpid));
			backpid[pidnum - 1] = pid;
		}	
	}
	else if(!in && !out && !next_in){
		if(strcmp(instr -> argv[0], "cd") == 0){
			if(instr -> argv[1] != NULL)
				chdir(instr -> argv[1]);
			else
				chdir(getenv("HOME"));
		}
		else if(strcmp(instr -> argv[0], "pwd") == 0){
			if(instr -> outfile != NULL){
				if(instr -> append)
					fd = open(instr -> outfile, O_APPEND|O_RDWR|O_CREAT, 0666);
				else
					fd = open(instr -> outfile, O_CREAT|O_RDWR|O_TRUNC, 0666);
				fd = open(instr -> outfile, O_APPEND|O_RDWR|O_CREAT, 0666);
				printcwd(fd);
				close(fd);
			}
			else if(out){
				printcwd(out);
			}
			else
				printcwd(1);
		}
		else{
			exit_FLAG = 1;
		}
	}
	if(instr -> backgrnd){
		fprintf(stderr, L_BLUE_C "Process %s started to execute with PID %d\n" STAND_C, instr -> argv == NULL? "" :instr -> argv[0], pid);
		fflush(stderr); 
	}
	return(pid);
}

void execute_pipeline(tree pipeline){
	int fd[2], in, out, next_in, num = 0, i, backgrnd, status, pid;
	int * nbpid = NULL;
	int nbpidnum = 0;
	if (pipeline == NULL) 
		return;
	if (pipeline -> pipe == NULL){
		pid = execute_instr(pipeline, 0, 0, 0);
		if(((pipeline -> argv == NULL) || !internal(pipeline -> argv[0])) && !(pipeline -> backgrnd)){
			waitpid(pid, &status, 0);
			fflush(stdout);
			if((!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status))) && !(WIFSIGNALED(status)))
				error_exec();
		}
		return;
	}
	/* argc>2 */
	if(pipe(fd) == -1) return;
	out=fd[1]; 
	next_in=fd[0];

	backgrnd = pipeline -> backgrnd;
	pid = execute_instr(pipeline, 0, out, next_in);
	if(((pipeline -> argv == NULL) || !internal(pipeline -> argv[0])) && !(pipeline -> backgrnd)){
		nbpid = realloc(nbpid, (++nbpidnum) * sizeof(*backpid));
		nbpid[nbpidnum - 1] = pid;
	}

	in=next_in;
	pipeline = pipeline -> pipe;
	for (;(pipeline -> pipe != NULL) && !exit_FLAG; pipeline = pipeline -> pipe){
		close(out);
		pipe(fd);
		out=fd[1];
		next_in=fd[0];
		pid = execute_instr(pipeline, in, out, next_in);
		close(in);
		in=next_in;
		if(((pipeline -> argv == NULL) || !internal(pipeline -> argv[0])) && !(pipeline -> backgrnd)){
			nbpid = realloc(nbpid, (++nbpidnum) * sizeof(*backpid));
			nbpid[nbpidnum - 1] = pid;
		}
	}
	close(out);
	if(!exit_FLAG){
		pid = execute_instr(pipeline, in, 0, 0);
		if(((pipeline -> argv == NULL) || !internal(pipeline -> argv[0])) && !(pipeline -> backgrnd)){
			nbpid = realloc(nbpid, (++nbpidnum) * sizeof(*backpid));
			nbpid[nbpidnum - 1] = pid;
		}
	}
		close(in);
	for(i=0; i<nbpidnum; i++){
		waitpid(nbpid[i], &status, 0);
		if((!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status))) && !(WIFSIGNALED(status)))
			error_exec();
		fflush(stdout);
	}
	free(nbpid);
}

int execute_shell_instr(tree shell_instr){
	while((shell_instr != NULL) && !exit_FLAG){
		execute_pipeline(shell_instr);
		shell_instr = shell_instr -> next;
	}
	return(exit_FLAG);
}
