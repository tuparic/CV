#ifndef EXEC_H
#define EXEC_H
int * backpid;
int pidnum;

int execute_shell_instr(tree);
void back_proc();
#endif



