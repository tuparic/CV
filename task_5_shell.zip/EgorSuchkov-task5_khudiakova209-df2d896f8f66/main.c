#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "tree.h"
#include "exec.h"
#include "colors.h"
#include <setjmp.h>
#include <signal.h>

#define show_FLAG 0
jmp_buf start;

void interrupt(){
	printf("\n");
	longjmp(start, 1);		
}

void inv(){
	char s[100]; /* ограничение: имя хоста и текущей директории не должно быть слишком длинным! */
	printf("%s", B_YELLOW_C); 
	gethostname(s, 100);
	printf("%s@%s", getenv("USER"), s);
	printf("%s", B_CYAN_C); 
	getcwd(s, 100);
	printf(":%s$ ", s);
	printf("%s", STAND_C); 
	fflush(stdout);
}

int main(){
	int end_FLAG = 0;
	tree p = NULL;
	words wd = NULL;
	backpid = NULL;
	pidnum = 0;
	signal(SIGINT, interrupt);
	while(1 == 1){
		setjmp(start);
		free(p);
		free(wd);
		p = NULL;
		wd = NULL;
		back_proc();
		inv();
		wd = list_make(&end_FLAG);
		if((wd != NULL) && (wd -> arr != NULL)){
			if(show_FLAG)
				out(wd);
			p = build_tree(wd);
			if(show_FLAG && (p != NULL)){
				fprintf(stderr, B_GREEN_C "\nMADE TREE\n" STAND_C);
				print_tree(p, 10);
			}
			if(show_FLAG)
				fprintf(stderr, B_GREEN_C "\nINSTRUCTION EXECUTING\n" STAND_C);
			end_FLAG = end_FLAG || execute_shell_instr(p);
			clear_tree(&p);
		}
		del_list(wd);
		if(show_FLAG)
			fprintf(stderr, B_GREEN_C "\nINSTRUCTION COMPLETED\n" STAND_C);
		if(end_FLAG)
			break;
	}
	free(backpid);
	free(p);
	free(wd);
}
