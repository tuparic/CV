#ifndef COLORS_H
#define COLORS_H

	#define BLUE_C "\x1b[34m"
	#define RED_C "\x1b[31m"
	#define GREEN_C "\x1b[32m"
	#define YELLOW_C "\x1b[33m"
	#define BLUE_C "\x1b[34m"
	#define L_BLUE_C "\x1b[94m"
	#define MAGENTA_C "\x1b[35m"
	#define CYAN_C "\x1b[36m"
	#define STAND_C "\x1b[0m"

	#define B_RED_C "\033[1;31m"
	#define B_YELLOW_C "\033[1;33m"
	#define B_BLUE_C "\033[1;34m"
	#define B_GREEN_C "\033[1;32m"
	#define B_CYAN_C "\x1b[1;36m"
#endif
